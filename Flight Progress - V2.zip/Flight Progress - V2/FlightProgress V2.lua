local toolName = "TNS|Flight Progress V2|TNE" 

-------------------------------------------------
-- CONSTANTS
-------------------------------------------------

local switches = {"SA","SB","SC","SD","SE","SF","SG","SH"}

local basePath = "/SCRIPTS/TOOLS/FlightProgress/"

-------------------------------------------------
-- LOAD MANEUVERS
-------------------------------------------------

local function loadManeuverFile(path)

  local list = {}

  local f = io.open(path, "r")

  if not f then
    message = "Missing Maneuver File"
    return list
  end

  local buffer = ""

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)

      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "\r", "")

      -------------------------------------------------
      -- Parse: 300,Straight & Level
      -------------------------------------------------

      local code, name =
        string.match(line, "^(%d+),(.+)$")

      if code and name then
        list[#list + 1] = {
          id = tonumber(code),
          name = name
        }
      end
    end

    if not chunk or chunk == "" then
      break
    end
  end

  io.close(f)

  return list
end

-------------------------------------------------
-- LOAD MAINTENANCE ITEMS
-------------------------------------------------

local function loadMaintenanceFile(path)

  local list = {}

  local f = io.open(path, "r")

  if not f then
    message =
      "Missing Service File"
    return list
  end

  local buffer = ""

  while true do

    local chunk =
      io.read(f, 128)

    if not chunk or chunk == "" then
      buffer =
        buffer .. "\n"
    else
      buffer =
        buffer .. chunk
    end

    while true do

      local s =
        string.find(
          buffer,
          "\n",
          1,
          true
        )

      if not s then
        break
      end

      local line =
        string.sub(
          buffer,
          1,
          s-1
        )

      buffer =
        string.sub(
          buffer,
          s+1
        )

      line =
        string.gsub(
          line,
          "\r",
          ""
        )

      local code, name =
        string.match(
          line,
          "^(%d+),(.+)$"
        )

      if code and name then

        list[#list + 1] = {
          id = code,
          name = name
        }
      end
    end

    if not chunk or chunk == "" then
      break
    end
  end

  io.close(f)

  return list

end

local modelName = model.getInfo().name
local safeName = string.gsub(modelName, "%W", "_")
local configPath = basePath .. safeName .. "_config.txt"

-------------------------------------------------
-- SPLASH
-------------------------------------------------

local splashStart = getTime()
local splashBmp   = bitmap.open(basePath .. "fp1.png")
local SPLASH_TIME = 400

-------------------------------------------------
-- MANEUVER LISTS
-------------------------------------------------

local heliManeuvers = {}
local planeManeuvers = {}

-------------------------------------------------
-- STATE
-------------------------------------------------

local page = 1           
local cursor  = 1
local hCursor = 1       
local planeScroll = 1
local heliScroll = 1
local serviceScroll = 1

local message = ""
local loaded  = false

local motorIdx = 1
local motorVal = 1024
local armIdx   = 0
local armVal   = 1024

-- maneuver 1 digits 
local d1, d2, d3 = 0,0,0

-- maneuver 2 digits
local m21, m22, m23 = 0,0,0   

-- yearly target digits
local y1, y2, y3 = 0,0,0

-------------------------------------------------
-- HISTORY DIGITS
-------------------------------------------------

local hd = {0,0,0,0,0,0} -- date YYYYMM
local hf = {0,0,0,0}     -- flights
local ht = {0,0,0,0,0,0} -- duration
local hc = {0,0,0}       -- crashes
local hy = {0,0,0}       -- ytarget

do
  local t = getDateTime()
  local d = string.format("%04d%02d",t.year,t.mon)

  for i=1,6 do
    hd[i] = tonumber(string.sub(d,i,i)) or 0
  end
end

-------------------------------------------------
-- MAINTENANCE TYPE
-------------------------------------------------

local serviceTypes = {
  {code="F", name="Full Service"},
  {code="P", name="Part Service"},
  {code="I", name="Inspection Only"},
  {code="C", name="Crash Repair"}
}

local serviceTypeIndex = 1   -- default Full Service

-------------------------------------------------
-- CRASH DETAILS
-------------------------------------------------

local crashReasons = {
  {code="P", name="Pilot Error"},
  {code="M", name="Mechanical Fault"},
  {code="E", name="Electronic Fault"},
  {code="O", name="Other"}
}

local crashReasonIndex = 1
local crashDate = {0,0,0,0,0,0,0,0}

do

  local t = getDateTime()

  local d = string.format("%04d%02d%02d",t.year,t.mon,t.day)

  for i=1,8 do
    crashDate[i] =tonumber(string.sub(d,i,i)) or 0
  end

end
-------------------------------------------------
-- MAINTENANCE DETAILS
-------------------------------------------------

local maintenanceItems = {}

local maintenanceOperations = {
  {code="I", name="Inspect"},
  {code="C", name="Clean"},
  {code="F", name="Fix"},
  {code="R", name="Replace"},
  {code="X", name="Rebuild"}
}

local maintenanceOperationIndex = 1

local sd1, sd2, sd3 = 0,0,0

local maintenanceDate = {0,0,0,0,0,0,0,0}

do
  local t = getDateTime()
  local d = string.format("%04d%02d%02d",t.year,t.mon,t.day)

  for i=1,8 do
    maintenanceDate[i] = tonumber(string.sub(d,i,i)) or 0
  end
end

-------------------------------------------------
-- MY BUDGET
-------------------------------------------------

local costTypes = {
  {code="N", name="New Model"},
  {code="R", name="Repair"},
  {code="M", name="Maintenance"},
  {code="S", name="Spares"},
  {code="O", name="Other"},
  {code="C", name="Credit"}
}

local costTypeIndex = 1

-- YEAR (DEFAULT CURRENT YEAR)
local yearDigits = {0,0,0,0}

do
  local t = getDateTime()
  local y = tostring(t.year)

  for i=1,4 do
    yearDigits[i] =
      tonumber(
        string.sub(y,i,i)
      ) or 0
  end
end

-- ANNUAL BUDGET
local budgetDigits = {0,0,0,0,0}

-- COST
local costDigits = {0,0,0,0,0}

-- DATE (YYYYMMDD)
local budgetDate = {0,0,0,0,0,0,0,0}

do
  local t = getDateTime()
  local d = string.format("%04d%02d%02d",t.year,t.mon,t.day)

  for i=1,8 do
    budgetDate[i] = tonumber(string.sub(d,i,i)) or 0
  end
end

-- NOTES (20 CHARS)
local budgetNotes = {}

for i=1,20 do
  budgetNotes[i] = " "
end
-------------------------------------------------
-- HELPERS
-------------------------------------------------

local function digitsToNumber(t)
  local v = 0
  for i=1,#t do v = v*10 + t[i] end
  return v
end

local function getManeuver()
  return d1*100 + d2*10 + d3
end

local function getService()
  return sd1*100 + sd2*10 + sd3
end

local function getYTarget()
  return y1*100 + y2*10 + y3
end

local function setDigitsFromValue(v)
  d1 = math.floor(v/100)
  d2 = math.floor((v%100)/10)
  d3 = v%10
end

local function setYDigitsFromValue(v)
  y1 = math.floor(v/100)
  y2 = math.floor((v%100)/10)
  y3 = v%10
end

-------------------------------------------------
-- BUDGET HELPERS
-------------------------------------------------

local function digitsToNumber(t)

  local n = ""

  for i=1,#t do
    n = n .. tostring(t[i])
  end

  return tonumber(n) or 0
end

local function textToString(t)

  local s = ""

  for i=1,20 do
    s = s .. t[i]
  end

  return s
end

local function nextChar(c)

  local chars = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  local i = string.find(chars,c,1,true) or 1
  i = i % #chars + 1

  return
    string.sub(chars,i,i)
end
-------------------------------------------------
-- CONFIG STORAGE
-------------------------------------------------

local function saveConfig()

  if not loaded then return end

  local f = io.open(configPath, "w")

  if f then

    io.write(f, motorIdx .. "\n")
    io.write(f, motorVal .. "\n")
    io.write(f, armIdx .. "\n")
    io.write(f, armVal .. "\n")

    io.write(f, getManeuver() .. "\n")
    io.write(f, (m21*100 + m22*10 + m23) .. "\n")
    io.write(f, getYTarget() .. "\n")

    io.close(f)

    message = "Saved"

  else
    message = "Save Failed"
  end
end


local function loadConfig()

  local f = io.open(configPath, "r")

  if not f then
    message = "Config Missing"
    return
  end

  local buffer = ""
  local values = {}

  while true do

    local chunk = io.read(f, 64)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "[^%-%d]", "")

      if line ~= "" then
        values[#values+1] = tonumber(line)
      end
    end

    if not chunk or chunk == "" then break end
  end

  io.close(f)

  -------------------------------------------------
  -- APPLY VALUES
  -------------------------------------------------

  if #values >= 7 then

    motorIdx = values[1] or motorIdx
    motorVal = values[2] or motorVal

    armIdx = values[3] or 0
    armVal = values[4] or 1024

    setDigitsFromValue(values[5] or 0)

    local m2 = values[6] or 0
    m21 = math.floor(m2/100)
    m22 = math.floor((m2%100)/10)
    m23 = m2%10

    setYDigitsFromValue(values[7] or 0)

    message = "Loaded Config"

  else
    message = "Bad Config"
  end
end

-------------------------------------------------
-- TIME HELPERS
-------------------------------------------------

local function nowTime()
  local t = getDateTime()
  return string.format("%02d:%02d:%02d", t.hour, t.min, t.sec)
end

local function nowDate()
  local t = getDateTime()
  return string.format("%04d-%02d-%02d", t.year, t.mon, t.day)
end

-------------------------------------------------
-- MODEL FILES
-------------------------------------------------

local function createModelFile()

  local info = model.getInfo()
  if not info or not info.name then
    message = "No Model"
    return
  end

  local base = basePath .. info.name

  -------------------------------------------------
  -- FILE HEADERS
  -------------------------------------------------

  local standardHeader =
  "ModelName,Date,StartTime,EndTime,Flight,TimeSeconds,Maneuver,Crash,YTarget,LineType,SrvType,SrvFltNbr\n"

  local operationsHeader =
  "ModelName,Date,StartTime,EndTime,Flight,TimeSeconds,Maneuver,Crash,YTarget,LineType,SrvType,SrvFltNbr,CReason\n"

  -------------------------------------------------
  -- File suffix list (No _SD File)
  -------------------------------------------------

  local suffixes = {

    ".txt",
    "_S.txt",
    "_O.txt",
    "_M.txt"

  }

  -------------------------------------------------
  -- Create files if missing
  -------------------------------------------------
local created = 0

for _, suffix in ipairs(suffixes) do

  if suffix then

    local path = base .. suffix

    local fileCheck = io.open(path, "r")

    if fileCheck then

      io.close(fileCheck)

    else

      local fileCreate = io.open(path, "w")

      if fileCreate then
        if suffix == "_O.txt" then
          io.write(fileCreate,operationsHeader)
        else
          io.write(fileCreate,standardHeader)
        end
        io.close(fileCreate)
        created = created + 1
      end


    end
  end
end
-------------------------------------------------
-- Status message
-------------------------------------------------

if created > 0 then
  message = created .. " Files Created"
else
  message = "Files Already Exist"
end

end

-------------------------------------------------
-- APPEND HISTORY
-------------------------------------------------

local function appendHistory()

  local info = model.getInfo()
  if not info then return end

  local path = basePath .. info.name .. "_O.txt"

  local dateNum = digitsToNumber(hd)
  local year  = math.floor(dateNum/100)
  local month = dateNum%100

  -- VALIDATE DATE
  if year < 2000 or month < 1 or month > 12 then
    message = "Invalid Year/Month"
    return
  end

  local flights  = digitsToNumber(hf)
  local duration = digitsToNumber(ht)
  local crashes  = digitsToNumber(hc)
  local ytarget  = digitsToNumber(hy)

  local line = string.format(
    "%s,%04d-%02d-01,00:00:00,00:00:00,%d,%d,0,%d,%d,H,Z,0,Z",
    info.name, year, month, flights, duration, crashes, ytarget
  )

  local fileHistory = io.open(path,"a")

  if fileHistory then
    io.write(fileHistory, line.."\n")
    io.close(fileHistory)
    message="History Saved"
  end

end

-------------------------------------------------
-- APPEND CRASH 
-------------------------------------------------

local function appendCrash()

  local info = model.getInfo()
  if not info then return end

  local path = basePath .. info.name .. "_O.txt"
  local t = nowTime()

  local entryDate = ""

  for i=1,8 do
    entryDate = entryDate.. tostring(crashDate[i])
  end

  entryDate =
    string.sub(entryDate,1,4)
    .. "-"
    .. string.sub(entryDate,5,6)
    .. "-"
    .. string.sub(entryDate,7,8)

  local crashReason = crashReasons[crashReasonIndex].code

  -- Read Maneuver Values From File
  local maneuver1 = getManeuver()
  local maneuver2 = m21*100 + m22*10 + m23
  local yTarget   = getYTarget()

  -- RS slider override 
  local slider = getValue("rs") or 0
  local maneuver

  if slider < -30 then
    maneuver = 0
  elseif slider < 30 then
    maneuver = maneuver2
  else
    maneuver = maneuver1
  end

-- Write crash line
local line = string.format("%s,%s,%s,%s,0,0,%d,1,%d,C,Z,0,%s", info.name, entryDate, t, t, maneuver, yTarget, crashReason)

local fileCrash = io.open(path,"a")

if fileCrash then
  io.write(fileCrash, line.."\n")
  io.close(fileCrash)
  message="Crash Logged"
end

end

-------------------------------------------------
-- APPEND MAINTENANCE DETAIL
-------------------------------------------------

local function appendMaintenanceDetail()

  local info = model.getInfo()

  if not info then
    message = "No Model"
    return
  end

  local service = string.format("%03d",getService())

  local serviceType = serviceTypes[serviceTypeIndex].code
  local operation = maintenanceOperations[maintenanceOperationIndex].code
  local path = basePath .. info.name .. "_SD.txt"

  -------------------------------------------------
  -- CREATE FILE HEADER
  -------------------------------------------------
  local check = io.open(path,"r")

  if check then
    io.close(check)
  else

    local hf = io.open(path,"w")

    if hf then
      io.write(hf,"ModelName,Date,Type,Operation,Service\n")
      io.close(hf)
    end
  end

  -------------------------------------------------
  -- WRITE LINE
  -------------------------------------------------

  local entryDate = ""

  for i=1,8 do
    entryDate = entryDate .. tostring(maintenanceDate[i])
  end

  entryDate =
    string.sub(entryDate,1,4)
    .. "-"
    .. string.sub(entryDate,5,6)
    .. "-"
    .. string.sub(entryDate,7,8)

  local line = string.format("%s,%s,%s,%s,%s\n",info.name,entryDate,serviceType,operation,getService())

  local f = io.open(path,"a")

  if f then
    io.write(f,line)
    io.close(f)
    message = "Maintenance Saved"
  else
    message = "Write Failed"
  end
end

-------------------------------------------------
-- APPEND BUDGET ENTRY
-------------------------------------------------

local function appendBudget()

  local path = basePath .. "Budget.txt"

  -------------------------------------------------
  -- CREATE FILE
  -------------------------------------------------

  local check = io.open(path,"r")

  if check then
    io.close(check)
  else

    local hf = io.open(path,"w")

    if hf then
      io.write(hf,"Year,Budget,CostType,Date,Cost,Notes\n")
      io.close(hf)
    end
  end

  -------------------------------------------------
  -- VALUES
  -------------------------------------------------
  local year = digitsToNumber(yearDigits)
  local budget = digitsToNumber(budgetDigits)
  local cost = digitsToNumber(costDigits)
  local costType = costTypes[costTypeIndex].code
  local notes = textToString(budgetNotes)

  -------------------------------------------------
  -- WRITE LINE
  -------------------------------------------------

  local entryDate = ""

  for i=1,8 do
    entryDate = entryDate .. tostring(budgetDate[i])
  end

  entryDate =
    string.sub(entryDate,1,4)
    .. "-"
    .. string.sub(entryDate,5,6)
    .. "-"
    .. string.sub(entryDate,7,8)

  local line = string.format("%d,%d,%s,%s,%d,%s\n",year,budget,costType,entryDate,cost,notes)

  local f = io.open(path,"a")

  if f then
    io.write(f,line)
    io.close(f)
    message = "Budget Saved"
  else
    message = "Save Failed"
  end
end

local function loadLastBudget()

  local path = basePath .. "Budget.txt"
  local f = io.open(path,"r")

  if not f then
    return
  end

  local lastLine = ""
  local buffer = ""

  while true do

    local chunk = io.read(f,128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer,"\n",1,true)

      if not s then
        break
      end

      local line = string.sub(buffer,1,s-1)

      buffer = string.sub(buffer,s+1)

      line = string.gsub(line,"\r","")

      if line ~= "" then
        lastLine = line
      end
    end

    if not chunk or chunk == "" then
      break
    end
  end

  io.close(f)

  -------------------------------------------------
  -- IGNORE HEADER
  -------------------------------------------------

  if string.find(lastLine,"Year",1,true) then
    return
  end

  -------------------------------------------------
  -- PARSE CSV
  -------------------------------------------------

  local year, budget = string.match(lastLine,"^(%d+),(%d+),")

  -------------------------------------------------
  -- YEAR
  -------------------------------------------------

  if year and string.len(year)==4 then

    for i=1,4 do
      yearDigits[i] = tonumber(string.sub(year,i,i)) or 0
    end
  end

  -------------------------------------------------
  -- BUDGET
  -------------------------------------------------

  if budget then

    budget = string.format("%05d",tonumber(budget))

    for i=1,5 do
      budgetDigits[i] = tonumber(string.sub(budget,i,i)) or 0
    end
  end
end

-------------------------------------------------
-- APPEND MAINTENANCE
-------------------------------------------------

local function appendMaintenance()

  local info = model.getInfo()
  if not info then return end

  local path = basePath .. info.name .. "_O.txt"
  local sumPath = basePath .. info.name .. "_S.txt"

  local t = nowTime()

  local srvCode = serviceTypes[serviceTypeIndex].code

  
  local totalFlights = 0

  local f = io.open(sumPath,"r")

  if f then

    local data = io.read(f, 1024*1024)
    io.close(f)

    if data then

      for line in string.gmatch(data,"([^\n]+)") do

        if not string.find(line,"ModelName",1,true) then

          local cols = {}

          for v in string.gmatch(line..",","([^,]*),") do
            cols[#cols+1] = v
          end

          local flights = tonumber(cols[5]) or 0

          totalFlights = totalFlights + flights

        end

      end

    end

  end

  local line = string.format(
  "%s,%s,%s,%s,0,0,0,0,%d,S,%s,%d,Z",
  info.name, nowDate(), t, t, getYTarget(), srvCode, totalFlights
  )


local fileMaint = io.open(path,"a")

if fileMaint then
  io.write(fileMaint, line.."\n")
  io.close(fileMaint)
  message="Maintenance Logged"
end

end

local function updateWidgetData()

  local info = model.getInfo()
  if not info or not info.name then
    message = "No Model"
    return
  end

  local mainPath = basePath .. info.name .. ".txt"
  local sumPath  = basePath .. info.name .. "_S.txt"

  local yearFlights = {}
  local yearSeconds = {}
  local yearTarget = {}

  -------------------------------------------------
  -- READ MAIN FILE
  -------------------------------------------------

  local fileMain = io.open(mainPath, "r")

  if fileMain == nil then
    message = "No Main File"
    return
  end

  local data = io.read(fileMain, 1024 * 1024)

  io.close(fileMain)

  if data == nil then
    message = "Read Failed"
    return
  end

  for line in string.gmatch(data, "([^\n]+)") do

    local cols = {}

    for v in string.gmatch(line .. ",", "([^,]*),") do
      cols[#cols+1] = v
    end

    if cols[10] == "L" and tonumber(cols[5]) == 1 then

      local year = string.sub(cols[2],1,4)
      local secs = tonumber(cols[6]) or 0

      yearFlights[year] = (yearFlights[year] or 0) + 1
      yearSeconds[year] = (yearSeconds[year] or 0) + secs
      
      local target = tonumber(cols[9]) or 0
      yearTarget[year] = target

    end

  end

  -------------------------------------------------
  -- WRITE SUMMARY FILE
  -------------------------------------------------

  local today = nowDate()
  local thisYear = string.sub(today,1,4)
  local yTarget = getYTarget()

  local fileSum = io.open(sumPath,"w")

  if fileSum == nil then
    message = "Write Failed"
    return
  end

  io.write(fileSum,
    "ModelName,Date,StartTime,EndTime,Flight,TimeSeconds,Maneuver,Crash,YTarget,LineType,SrvType,SrvFltNbr\n"
  )

  local years = {}

  for y in pairs(yearFlights) do
    years[#years+1] = y
  end

  table.sort(years)

  for i=1,#years do

    local year = years[i]
    local flights = yearFlights[year]
    local secs = yearSeconds[year] or 0

    local date

    if year == thisYear then
      date = today
    else
      date = year .. "-12-31"
    end

    local finalTarget
    if year == thisYear then
      finalTarget = yTarget
    else
     finalTarget = yearTarget[year] or 0
    end

    local outLine = string.format(
      "%s,%s,00:00:00,00:00:00,%d,%d,0,0,%d,L,Z,0\n",
      info.name,
      date,
      flights,
      secs,
      finalTarget
    )

    io.write(fileSum, outLine)

  end

  io.close(fileSum)

-------------------------------------------------
-- WRITE MANEUVER SUMMARY FILE (_M)
-------------------------------------------------

local manPath = basePath .. info.name .. "_M.txt"

local manFlights = {}
local manSeconds = {}
local manLastDate = {}
local manTarget = {}

-------------------------------------------------
-- READ MAIN FILE AGAIN
-------------------------------------------------

for line in string.gmatch(data, "([^\n]+)") do

  local cols = {}

  for v in string.gmatch(line .. ",", "([^,]*),") do
    cols[#cols+1] = v
  end

  if cols[10] == "L" then

    local date = cols[2]
    local year = string.sub(date,1,4)
    local maneuver = tonumber(cols[7]) or 0

    if maneuver > 0 then

      local key = year .. "_" .. maneuver

      local flights = tonumber(cols[5]) or 0
      local secs    = tonumber(cols[6]) or 0
      local target  = tonumber(cols[9]) or 0

      manFlights[key] = (manFlights[key] or 0) + flights
      manSeconds[key] = (manSeconds[key] or 0) + secs
      manTarget[key]  = target

      if not manLastDate[key] or date > manLastDate[key] then
        manLastDate[key] = date
      end

    end
  end
end

-------------------------------------------------
-- WRITE FILE
-------------------------------------------------

local fileMan = io.open(manPath,"w")

if fileMan == nil then
  message = "M File Write Failed"
  return
end

io.write(fileMan,
"ModelName,Date,StartTime,EndTime,Flight,TimeSeconds,Maneuver,Crash,YTarget,LineType,SrvType,SrvFltNbr\n"
)

local keys = {}

for k in pairs(manFlights) do
  keys[#keys+1] = k
end

table.sort(keys)

for i=1,#keys do

  local key = keys[i]

  local year, maneuver =
    string.match(key,"(%d+)_([^_]+)")

  local line = string.format(
  "%s,%s,00:00:00,00:00:00,%d,%d,%d,0,%d,L,Z,0\n",
  info.name,
  manLastDate[key],
  manFlights[key],
  manSeconds[key],
  tonumber(maneuver),
  manTarget[key] or 0
  )

  io.write(fileMan,line)

end

io.close(fileMan)

  message = "Summary Data Updated"

end

-------------------------------------------------
-- DRAW
-------------------------------------------------

local function drawRow(y,label,value,sel)
  lcd.drawText(40,y,label)
  lcd.drawText(320,y,tostring(value), sel and INVERS or 0)
end

local function drawDigitsRow(y,label,t,selStart)
  lcd.drawText(40,y,label)
  local x=320
  for i=1,#t do
    lcd.drawText(x+(i-1)*12,y,tostring(t[i]), hCursor==(selStart+i-1) and INVERS or 0)
  end
end

-------------------------------------------------
-- MAIN
-------------------------------------------------

local function run(event)

  if splashBmp and (getTime() - splashStart < SPLASH_TIME) then
    lcd.clear()
    lcd.drawBitmap(splashBmp,0,0)
    return 0
  end

  if not loaded then
    loadConfig()
    loadLastBudget()
    heliManeuvers = loadManeuverFile(basePath .. "heli_maneuvers.txt")
    planeManeuvers = loadManeuverFile(basePath .. "plane_maneuvers.txt")
    maintenanceItems = loadMaintenanceFile(basePath .."maintenance_operations.txt")
    loaded = true
  end

  lcd.clear()

  -------------------------------------------------
  -- PAGE 1 : SETUP
  -------------------------------------------------
  if page==1 then

  lcd.drawText(LCD_W/2,15,"Model Setup",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local y=65
  local s=22

  drawRow(y+s*0,"Motor Switch", switches[motorIdx], cursor==1)
  drawRow(y+s*1,"Motor Value",  motorVal, cursor==2)

  drawRow(y+s*2,"Arm Switch", armIdx==0 and "DISABLED" or switches[armIdx], cursor==3)
  drawRow(y+s*3,"Arm Value", armVal, cursor==4)

  drawRow(y+s*4,"Create File","ENTER", cursor==5)
  drawRow(y+s*5,"Update Summary Data","ENTER", cursor==6)
  drawRow(y+s*7,"Next Page","ENTER", cursor==7)

  lcd.drawText(40,250,message,SMLSIZE)

  -- Page indicator
  lcd.drawText(LCD_W-70, 250, "Page 1/8", SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then cursor=cursor%7+1 end
  if event==EVT_VIRTUAL_PREV then cursor=(cursor-2)%7+1 end

  if event==EVT_VIRTUAL_ENTER then
    if cursor==5 then createModelFile()
    elseif cursor==6 then updateWidgetData()
    elseif cursor==7 then page=2; cursor=1; return 0

    elseif cursor==1 then motorIdx=motorIdx%#switches+1; saveConfig()
    elseif cursor==2 then motorVal=(motorVal==1024 and -1024 or 1024); saveConfig()
    elseif cursor==3 then armIdx=(armIdx+1)%(#switches+1); saveConfig()
    elseif cursor==4 then armVal=(armVal==1024 and -1024 or 1024); saveConfig()
    end
  end
end

-------------------------------------------------
-- PAGE 2 : FLYING SETUP
-------------------------------------------------
if page==2 then

  lcd.drawText(LCD_W/2,15,"Flying Setup",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local y=65
  local s=22
  local x=320

  -------------------------------------------------
  -- Maneuver 1
  -------------------------------------------------
  lcd.drawText(40,y+s*0,"Maneuver 1")
  lcd.drawText(x,     y+s*0, tostring(d1), cursor==1 and INVERS or 0)
  lcd.drawText(x+12,  y+s*0, tostring(d2), cursor==2 and INVERS or 0)
  lcd.drawText(x+24,  y+s*0, tostring(d3), cursor==3 and INVERS or 0)

  -------------------------------------------------
  -- Maneuver 2
  -------------------------------------------------
  lcd.drawText(40,y+s*1,"Maneuver 2")
  lcd.drawText(x,     y+s*1, tostring(m21), cursor==4 and INVERS or 0)
  lcd.drawText(x+12,  y+s*1, tostring(m22), cursor==5 and INVERS or 0)
  lcd.drawText(x+24,  y+s*1, tostring(m23), cursor==6 and INVERS or 0)

  -------------------------------------------------
  -- Yearly Target
  -------------------------------------------------
  lcd.drawText(40,y+s*2,"Yearly Flight Target")
  lcd.drawText(x,     y+s*2, tostring(y1), cursor==7 and INVERS or 0)
  lcd.drawText(x+12,  y+s*2, tostring(y2), cursor==8 and INVERS or 0)
  lcd.drawText(x+24,  y+s*2, tostring(y3), cursor==9 and INVERS or 0)

  -------------------------------------------------
  drawRow(y+s*4,"Previous Page","ENTER", cursor==10)
  drawRow(y+s*5,"Next Page","ENTER", cursor==11)

  -- Page indicator
  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70, 250, "Page 2/8", SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then cursor=cursor%11+1 end
  if event==EVT_VIRTUAL_PREV then cursor=(cursor-2)%11+1 end

  if event==EVT_VIRTUAL_ENTER then

    if cursor<=3 then
      if cursor==1 then d1=(d1+1)%10 end
      if cursor==2 then d2=(d2+1)%10 end
      if cursor==3 then d3=(d3+1)%10 end
      saveConfig()

    elseif cursor<=6 then
      if cursor==4 then m21=(m21+1)%10 end
      if cursor==5 then m22=(m22+1)%10 end
      if cursor==6 then m23=(m23+1)%10 end
      saveConfig()

    elseif cursor<=9 then
      if cursor==7 then y1=(y1+1)%10 end
      if cursor==8 then y2=(y2+1)%10 end
      if cursor==9 then y3=(y3+1)%10 end
      saveConfig()

    elseif cursor==10 then
      page=1; cursor=1

    elseif cursor==11 then
      page=3; hCursor=1; return 0
    end
  end
end

  -------------------------------------------------
  -- PAGE 3 : LOGGING PAGE
  -------------------------------------------------
  if page==3 then

  lcd.drawText(LCD_W/2,15,"Flight Logging",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local y=65
  local s=22

  lcd.drawText(40,y+s*0,"Crash Date & Reason")

  for i=1,8 do
    lcd.drawText(210 + (i-1)*12,y+s*0,tostring(crashDate[i]),cursor==i and INVERS or 0)
  end

  lcd.drawText(320,y+s*0,crashReasons[crashReasonIndex].name,cursor==9 and INVERS or 0)

  drawRow(y+s*1,"Log Crash","ENTER",cursor==10)
  drawRow(y+s*2,"Maintenance Type",serviceTypes[serviceTypeIndex].name,cursor==11)
  drawRow(y+s*3,"Log Maintenance","ENTER",cursor==12)
  drawRow(y+s*5,"Previous Page","ENTER",cursor==13)
  drawRow(y+s*6,"Next Page","ENTER",cursor==14)

  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70,250,"Page 3/8",SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then cursor = cursor%14 + 1 end
  if event==EVT_VIRTUAL_PREV then cursor = (cursor-2)%14 + 1 end
  
  if event==EVT_VIRTUAL_ENTER then
    if cursor<=8 then
      crashDate[cursor] = (crashDate[cursor] + 1) % 10
    elseif cursor==9 then
      crashReasonIndex = crashReasonIndex % #crashReasons + 1
    elseif cursor==10 then
      appendCrash()
    elseif cursor==11 then
      serviceTypeIndex = serviceTypeIndex % #serviceTypes + 1
    elseif cursor==12 then
      appendMaintenance()

    elseif cursor==13 then
      page = 2
      cursor = 1

    elseif cursor==14 then
      page = 4
      cursor = 1
      serviceScroll = 1
      return 0
    end
  end

end

  
-------------------------------------------------
-- PAGE 4 : MAINTENANCE DETAILS
-------------------------------------------------

if page==4 then

  lcd.drawText(LCD_W/2,15,"MAINTENANCE DETAILS",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  local y=65
  local s=22
  local x=320

  drawRow(y+s*0,"Maintenance Type",serviceTypes[serviceTypeIndex].name,cursor==1)

  drawRow(y+s*1,"Operation",maintenanceOperations[maintenanceOperationIndex].name,cursor==2)

  lcd.drawText(40,y+s*2,"Date & Service")

  for i=1,8 do
    lcd.drawText(200 + (i-1)*12,y+s*2,tostring(maintenanceDate[i]),cursor==(2+i) and INVERS or 0)
  end

  lcd.drawText(320,y+s*2,tostring(sd1),cursor==11 and INVERS or 0)
  lcd.drawText(332,y+s*2,tostring(sd2),cursor==12 and INVERS or 0)
  lcd.drawText(344,y+s*2,tostring(sd3),cursor==13 and INVERS or 0)

  -------------------------------------------------
  -- SERVICE LIST
  -------------------------------------------------
  local rows = 3
  local listY = y+s*3

  lcd.drawText(40,listY,"Service List: " .. #maintenanceItems .. " Items",SMLSIZE)

  for i=0,rows-1 do

    local idx = serviceScroll + i

    local item = maintenanceItems[idx]

    if item then
      lcd.drawText(40,listY + 12 + (i*12),item.id .. " - " .. item.name,SMLSIZE)
    end
  end

  local btnOffset = -3
  drawRow(y+s*6 + btnOffset,"Save","ENTER",cursor==14)
  drawRow(y+s*7 + btnOffset*2,"Previous Page","ENTER",cursor==15)
  drawRow(y+s*8 + btnOffset*3,"Next Page","ENTER",cursor==16)

  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70,250,"Page 4/8",SMLSIZE)

  -------------------------------------------------
  -- NAVIGATION
  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then
  if cursor == 13 then

    if serviceScroll < (#maintenanceItems - 2) then
      serviceScroll = serviceScroll + 1
    else
      cursor = 14
    end

  else

    cursor = cursor%16 + 1
  end
  end

  if event==EVT_VIRTUAL_PREV then
  if cursor == 13 then
    cursor = 12

  elseif cursor == 14 then

    if serviceScroll > 1 then
      serviceScroll = serviceScroll - 1
    else
      cursor = 13
    end

  else
    cursor = (cursor-2)%16 + 1
  end
  end

  -------------------------------------------------
  -- ENTER
  -------------------------------------------------

  if event==EVT_VIRTUAL_ENTER then

  if cursor==1 then

    serviceTypeIndex = serviceTypeIndex % #serviceTypes + 1

  elseif cursor==2 then

    maintenanceOperationIndex = maintenanceOperationIndex % #maintenanceOperations + 1

  elseif cursor<=10 then

    local idx = cursor - 2
    maintenanceDate[idx] = (maintenanceDate[idx] + 1) % 10

  elseif cursor==11 then 
    sd1 = (sd1+1)%10

  elseif cursor==12 then
    sd2 = (sd2+1)%10

  elseif cursor==13 then
    sd3 = (sd3+1)%10

  -------------------------------------------------
  -- SAVE
  -------------------------------------------------

  elseif cursor==14 then
    appendMaintenanceDetail()

  elseif cursor==15 then
    page = 3
    cursor = 1

  elseif cursor==16 then
    page = 5
    cursor = 1
    return 0
  end
end

end

  -------------------------------------------------
  -- PAGE 5 : MY BUDGET
  -------------------------------------------------

  if page==5 then

  lcd.drawText(LCD_W/2,15,"MY BUDGET",DBLSIZE + CENTER)
  lcd.drawLine(10,55,LCD_W-10,55,SOLID,0)

  local y=65
  local s=22
  local x=320

  -------------------------------------------------
  -- YEAR
  -------------------------------------------------

  lcd.drawText(40,y+s*0,"Year")

  for i=1,4 do

    lcd.drawText(
      x + (i-1)*12,
      y+s*0,
      tostring(
        yearDigits[i]
      ),
      cursor==(i) and INVERS or 0
    )
  end

  -------------------------------------------------
  -- ANNUAL BUDGET
  -------------------------------------------------

  lcd.drawText(40,y+s*1,"Annual Budget")

  for i=1,5 do

    lcd.drawText(
      x + (i-1)*12,
      y+s*1,
      tostring(
        budgetDigits[i]
      ),
      cursor==(4+i) and INVERS or 0
    )
  end

  -------------------------------------------------
  -- COST TYPE
  -------------------------------------------------

  drawRow(y+s*2,"Cost Type",costTypes[costTypeIndex].name,cursor==10)

  -------------------------------------------------
  -- COST
  -------------------------------------------------

  lcd.drawText(40,y+s*3,"Cost")

  for i=1,5 do

    lcd.drawText(
      x + (i-1)*12,
      y+s*3,
      tostring(
        costDigits[i]
      ),
      cursor==(10+i) and INVERS or 0
    )
  end


  -------------------------------------------------
  -- DATE
  -------------------------------------------------

  lcd.drawText(40,y+s*4,"Date")

  for i=1,8 do

    lcd.drawText(x + (i-1)*12,y+s*4,tostring(budgetDate[i]),
      cursor==(15+i) and INVERS or 0)
  end
  -------------------------------------------------
  -- NOTES
  -------------------------------------------------

  for i=1,20 do

    lcd.drawText(
      150 + (i-1)*8,
      y+s*4,
      budgetNotes[i],
      cursor==(23+i) and INVERS or 0
    )
  end

  -------------------------------------------------
  -- BUTTONS
  -------------------------------------------------

  local btnOffset = -3

  drawRow(y+s*6 + btnOffset,"Save","ENTER",cursor==44)
  drawRow(y+s*7 + (btnOffset*2),"Previous Page","ENTER",cursor==45)
  drawRow(y+s*8 + (btnOffset*3),"Next Page","ENTER",cursor==46)

  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70,250,"Page 5/8",SMLSIZE)

  -------------------------------------------------
  -- NAVIGATION
  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then
    cursor = cursor%46 + 1
  end

  if event==EVT_VIRTUAL_PREV then
    cursor = (cursor-2)%46 + 1
  end

  -------------------------------------------------
  -- ENTER
  -------------------------------------------------

  if event==EVT_VIRTUAL_ENTER then

    -------------------------------------------------
    -- YEAR
    -------------------------------------------------

    if cursor <= 4 then

      yearDigits[cursor] = (yearDigits[cursor] + 1) % 10

    -------------------------------------------------
    -- BUDGET
    -------------------------------------------------

    elseif cursor <= 9 then

      local idx = cursor - 4

      budgetDigits[idx] = (budgetDigits[idx] + 1) % 10

    -------------------------------------------------
    -- COST TYPE
    -------------------------------------------------

    elseif cursor == 10 then

      costTypeIndex = costTypeIndex % #costTypes + 1

    -------------------------------------------------
    -- COST
    -------------------------------------------------

    elseif cursor <= 15 then

      local idx = cursor - 10
      costDigits[idx] = (costDigits[idx] + 1) % 10

    -------------------------------------------------
    -- DATE
    -------------------------------------------------

    elseif cursor <= 23 then

      local idx = cursor - 15

      budgetDate[idx] = (budgetDate[idx] + 1) % 10

    -------------------------------------------------
    -- NOTES
    -------------------------------------------------

    elseif cursor <= 43 then

      local idx = cursor - 23
      budgetNotes[idx] = nextChar(budgetNotes[idx])

    -------------------------------------------------
    -- SAVE
    -------------------------------------------------

    elseif cursor == 44 then

      appendBudget()

    -------------------------------------------------
    -- PREVIOUS / NEXT
    -------------------------------------------------

    elseif cursor == 45 then

      page = 4
      cursor = 1

    elseif cursor == 46 then

      page = 6
      cursor = 1
      return 0
    end
  end
end
  -------------------------------------------------
  -- PAGE 6 : HISTORY PAGE
  -------------------------------------------------

  if page==6 then

  lcd.drawText(LCD_W/2,15,"History Entry",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local y=65
  local s=20

  drawDigitsRow(y+s*0,"Date YYYYMM",hd,1)
  drawDigitsRow(y+s*1,"Flights",hf,7)
  drawDigitsRow(y+s*2,"Duration (Seconds)",ht,11)
  drawDigitsRow(y+s*3,"Crashes",hc,17)
  drawDigitsRow(y+s*4,"Yearly Target",hy,20)

  drawRow(y+s*5,"Save","ENTER", hCursor==23)
  drawRow(y+s*6,"Previous Page","ENTER", hCursor==24)
  drawRow(y+s*7,"Next Page","ENTER", hCursor==25)

  -- Page indicator
  lcd.drawText(40,250,message,SMLSIZE)
  lcd.drawText(LCD_W-70, 250, "Page 6/8", SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then hCursor=hCursor%25+1 end
  if event==EVT_VIRTUAL_PREV then hCursor=(hCursor-2)%25+1 end

  if event==EVT_VIRTUAL_ENTER then
    if hCursor<=6 then hd[hCursor]=(hd[hCursor]+1)%10
    elseif hCursor<=10 then hf[hCursor-6]=(hf[hCursor-6]+1)%10
    elseif hCursor<=16 then ht[hCursor-10]=(ht[hCursor-10]+1)%10
    elseif hCursor<=19 then hc[hCursor-16]=(hc[hCursor-16]+1)%10
    elseif hCursor<=22 then hy[hCursor-19]=(hy[hCursor-19]+1)%10

    elseif hCursor==23 then appendHistory()
    elseif hCursor==24 then page=5; cursor=1
    elseif hCursor==25 then page=7; cursor=1; hCursor=1; return 0
    end
  end
end

-------------------------------------------------
-- PAGE 7 - PLANE MANEUVER LIST
-------------------------------------------------
if page==7 then

  lcd.drawText(LCD_W/2,15,"Plane Maneuver List",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local maneuvers = planeManeuvers

  local rows = 10
  local y = 70
  local s = 17

  planeScroll = planeScroll or 1

  -------------------------------------------------
  -- draw visible slice
  -------------------------------------------------
  for i=0,rows-1 do

    local idx = planeScroll + i

    if maneuvers[idx] then

      local m = maneuvers[idx]

      lcd.drawText(
        40,
        y + i*s,
        m.id .. " - " .. m.name,
        SMLSIZE
      )
    end
  end

  -------------------------------------------------
  -- buttons (bottom)
  -------------------------------------------------
  drawRow(245,"Next Page","ENTER", cursor==1)

  lcd.drawText(LCD_W-70, 250, "Page 7/8", SMLSIZE)

  -------------------------------------------------
  -- navigation
  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then
    if planeScroll < (#maneuvers - rows + 1) then
      planeScroll = planeScroll + 1
    end
  end

  if event==EVT_VIRTUAL_PREV then
    if planeScroll > 1 then
      planeScroll = planeScroll - 1
    end
  end

  if event==EVT_VIRTUAL_ENTER then
    page = 8
    cursor = 1
    return 0
  end

end

-------------------------------------------------
-- PAGE 8 - HELI MANEUVER LIST
-------------------------------------------------
if page==8 then

  lcd.drawText(LCD_W/2,15,"Helicopter Maneuver List",DBLSIZE + CENTER)
  lcd.drawLine(10, 55, LCD_W-10, 55, SOLID, 0)

  local maneuvers = heliManeuvers

  local rows = 10
  local y = 70
  local s = 17

  heliScroll = heliScroll or 1

  -------------------------------------------------
  -- draw visible slice
  -------------------------------------------------
  for i=0,rows-1 do

    local idx = heliScroll + i

    if maneuvers[idx] then

      local m = maneuvers[idx]

      lcd.drawText(
        40,
        y + i*s,
        m.id .. " - " .. m.name,
        SMLSIZE
      )
    end
  end

  -------------------------------------------------
  -- Empty list fallback
  -------------------------------------------------
  if #maneuvers == 0 then
    lcd.drawText(40, y, "List coming soon...", SMLSIZE)
  end

  -------------------------------------------------
  -- button
  -------------------------------------------------
  drawRow(245,"Next Page","ENTER", true)

  lcd.drawText(LCD_W-70, 250, "Page 8/8", SMLSIZE)

  -------------------------------------------------
  -- scrolling
  -------------------------------------------------
  if event==EVT_VIRTUAL_NEXT then
    if heliScroll < (#maneuvers - rows + 1) then
      heliScroll = heliScroll + 1
    end
  end

  if event==EVT_VIRTUAL_PREV then
    if heliScroll > 1 then
      heliScroll = heliScroll - 1
    end
  end

  -------------------------------------------------
  -- next page
  -------------------------------------------------
  if event==EVT_VIRTUAL_ENTER then
    page = 1
    cursor = 1
    return 0
  end

end
 
  return 0
end

return { run=run }
