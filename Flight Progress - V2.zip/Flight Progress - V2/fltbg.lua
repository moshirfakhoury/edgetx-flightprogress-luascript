-------------------------------------------------
-- CONSTANTS
-------------------------------------------------

local switches = {"SA","SB","SC","SD","SE","SF","SG","SH"}

local basePath = "/SCRIPTS/TOOLS/FlightProgress/"

local modelName = model.getInfo().name
local safeName = string.gsub(modelName, "%W", "_")
local configPath = basePath .. safeName .. "_config.txt"

-------------------------------------------------
-- STATE
-------------------------------------------------
local yTarget = 0

local maneuver1 = 0
local maneuver2 = 0

local motorIdx = 1
local motorVal = 1024

local armIdx = 0
local armVal = 1024

local lastOn    = nil
local startSec  = 0
local startTime = ""

-------------------------------------------------
-- TIME HELPERS
-------------------------------------------------

local function nowTime()
  local t = getDateTime()
  return string.format("%02d:%02d:%02d", t.hour, t.min, t.sec)
end

local function nowDate()
  local t = getDateTime()
  return string.format("%04d-%02d-%02d", t.year, t.mon, t.day)
end

local function nowSeconds()
  local t = getDateTime()
  return t.hour*3600 + t.min*60 + t.sec
end

-------------------------------------------------
-- LOAD CONFIG
-------------------------------------------------

local function loadConfig()

  local f = io.open(configPath, "r")

  if not f then
    return
  end

  local buffer = ""
  local values = {}

  while true do

    local chunk = io.read(f, 64)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "[^%-%d]", "")

      if line ~= "" then
        values[#values+1] = tonumber(line)
      end
    end

    if not chunk or chunk == "" then break end
  end

  io.close(f)

  -------------------------------------------------
  -- APPLY VALUES
  -------------------------------------------------

  if #values >= 7 then

    motorIdx = values[1] or 1
    motorVal = values[2] or 1024

    armIdx = values[3] or 0
    armVal = values[4] or 1024

    maneuver1 = values[5] or 0
    maneuver2 = values[6] or 0
    yTarget   = values[7] or 0
  end
end

-------------------------------------------------
-- WRITE LOG LINE
-------------------------------------------------

local function appendFlight(seconds, maneuver, yTarget)

  local info = model.getInfo()
  if not info then return end

  local path = basePath .. info.name .. ".txt"
  local sumPath = basePath .. info.name .. "_S.txt"


  local flag = (seconds >= 60) and 1 or 0

  local line = string.format(
    "%s,%s,%s,%s,%d,%d,%d,0,%d,L,Z,0\n",
    info.name,
    nowDate(),
    startTime,
    nowTime(),
    flag,
    seconds,
    maneuver,
    yTarget
  )

  local f = io.open(path,"a")
  if f then
    io.write(f,line)
    io.close(f)
  end
  
  local fs = io.open(sumPath,"a")
  if fs then
    io.write(fs,line)
    io.close(fs)
  end

end

-------------------------------------------------
-- MAIN LOOP
-------------------------------------------------

local function run()

  -------------------------------------------------
  -- If 6POS5 is enabled do not write to model file
  -------------------------------------------------

  local POS5Id = getSwitchIndex("6POS5") 
  if POS5Id then
    local is6Pos5On = getSwitchValue(POS5Id)
  if is6Pos5On then
    return
  end
  end

  -------------------------------------------------
  -- Read config file
  -------------------------------------------------

  loadConfig()

  -------------------------------------------------
  -- RS Slider Controls Maneuver Selection
  -------------------------------------------------

  local MANEUVER_OVERRIDE_SRC = "rs"
  local slider = getValue(MANEUVER_OVERRIDE_SRC) or 0

  local maneuver

  if slider < - 30 then
    maneuver = 0                -- down
  elseif slider < 30 then
    maneuver = maneuver2        -- middle
  else
    maneuver = maneuver1        -- up
  end

  -------------------------------------------------
  -- motor
  -------------------------------------------------

  local motorRaw = getValue(switches[motorIdx]) or 0

  local motorOn =
      (motorVal > 0 and motorRaw > 0) or
      (motorVal < 0 and motorRaw < 0)

  -------------------------------------------------
  -- optional arm
  -------------------------------------------------

  local on

  if armIdx >= 1 then
    local armRaw = getValue(switches[armIdx]) or 0

    local armOn =
        (armVal > 0 and armRaw > 0) or
        (armVal < 0 and armRaw < 0)

    on = motorOn and armOn
  else
    on = motorOn
  end

  -------------------------------------------------
  -- first sync
  -------------------------------------------------

  if lastOn == nil then
    lastOn = on
    return
  end

  -------------------------------------------------
  -- start
  -------------------------------------------------

  if on and not lastOn then
    startSec  = nowSeconds()
    startTime = nowTime()
  end

  -------------------------------------------------
  -- stop
  -------------------------------------------------

  if not on and lastOn then
    appendFlight(nowSeconds() - startSec, maneuver, yTarget) -- NEW
  end

  lastOn = on
end

-------------------------------------------------

return { run = run }
