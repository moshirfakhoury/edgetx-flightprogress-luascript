---------------------------------------------------------------------------
-- FlightProgress YEAR STATS WIDGET
---------------------------------------------------------------------------

local name = "fltprgW1"

local maneuverNames = {}

---------------------------------------------------------------------------
-- LOAD MANEUVERS
---------------------------------------------------------------------------

local function loadManeuverFile(path)

  local f = io.open(path, "r")

  if not f then
    return
  end

  local buffer = ""

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)

      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "\r", "")

      -------------------------------------------------
      -- Parse: 300,Straight & Level
      -------------------------------------------------

      local code, name =
        string.match(line, "^(%d+),(.+)$")

      if code and name then
        maneuverNames[tonumber(code)] = name
      end
    end

    if not chunk or chunk == "" then
      break
    end
  end

  io.close(f)
end

local options = {
  { "Additional Year", STRING, "" },
  { "Budget Year", STRING, "" },
  { "Search", STRING, "" },
  { "Scroll Up Pos", SOURCE, nil },
  { "Scroll Down Pos", SOURCE, nil },
  { "Scroll Switch", SOURCE, nil }
}

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

local function create(zone, opts)
  local now = getDateTime()
  local info = model.getInfo()

  local configPath = nil

  if info and info.name then
    local safeName = string.gsub(info.name, "%W", "_")
    configPath = "/SCRIPTS/TOOLS/FlightProgress/".. safeName .."_config.txt"
  end

loadManeuverFile("/SCRIPTS/TOOLS/FlightProgress/heli_maneuvers.txt")
loadManeuverFile("/SCRIPTS/TOOLS/FlightProgress/plane_maneuvers.txt")

  local w = {
    zone = zone,
    options = opts or {},
    budgetYear = now.year,
    thisYear = now.year,
    lastYear = now.year - 1,
    extraYear = nil,

    maneuverSet = {},
    maneuverCount = 0,

    -- Totals
    tFlights = 0, tSeconds = 0, tCrashes = 0, tServices = 0,
    yFlights = 0, ySeconds = 0, yCrashes = 0, yTarget = 0, yServices = 0,
    pFlights = 0, pSeconds = 0, pCrashes = 0, pTarget = 0, pServices = 0,
    

    -- per year table
    yearStats = {},

    fileS = nil,
    fileO = nil,
    bufferS = "",
    bufferO = "",

    fileMain = nil,
    bufferMain = "",
    fileM = nil,
    bufferM = "",
    lastFlightDate = "",
    doneMain = false,

    configPath = configPath,

    maneuver1 = 0,
    maneuver2 = 0,

    budgetYear = now.year,
    budget = 0,
    used = 0,
    remaining = 0,
    usedPct = 0,

    costN = 0,
    costR = 0,
    costM = 0,
    costS = 0,
    costO = 0,
    costC = 0,

    budgetLoaded = false,
    budgetRows = {},
    budgetScroll = 1,
    scrollUpPos = nil,
    scrollDownPos = nil,
    scrollSwitch = nil,
    lastScrollValue = 0,
    searchText = "",
    
    totalSpend = 0,
    totalCredit = 0,

  }

  if info then
    local base = "/SCRIPTS/TOOLS/FlightProgress/" .. info.name

    w.fileS = io.open(base .. "_S.txt", "r")
    w.fileO = io.open(base .. "_O.txt", "r")
    w.fileMain = io.open(base .. ".txt", "r")
    w.fileM = io.open(base .. "_M.txt", "r")
  end

  return w
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------

local function update(widget, opts)
  widget.options = opts

  local raw = opts["Additional Year"]
  local budgetRaw = opts["Budget Year"]
  local searchRaw = opts["Search"]

  -- BUDGET YEAR
  if budgetRaw and budgetRaw ~= "" then
    widget.budgetYear =
      tonumber(string.match(budgetRaw,"%d%d%d%d")) or widget.thisYear
  else
    widget.budgetYear = widget.thisYear
  end

  -- FORCE BUDGET RELOAD
  widget.budgetLoaded = false

  widget.budget = 0
  widget.used = 0
  widget.remaining = 0
  widget.usedPct = 0

  widget.costN = 0
  widget.costR = 0
  widget.costM = 0
  widget.costS = 0
  widget.costO = 0
  widget.costC = 0

  -- ADDITIONAL YEAR
  if raw and raw ~= "" then
    widget.extraYear = tonumber(string.match(raw, "%d%d%d%d"))
  else
    widget.extraYear = nil
  end
  
  -- SCROLL OPTIONS
  widget.scrollUpPos = opts["Scroll Up Pos"]
  widget.scrollDownPos = opts["Scroll Down Pos"]
  widget.scrollSwitch = opts["Scroll Switch"]
  
  -- SEARCH TEXT / REST SCROLL
  widget.searchText = searchRaw or ""
  widget.budgetScroll = 1

end

---------------------------------------------------------------------------
-- LOAD CONFIG
---------------------------------------------------------------------------

local function loadConfig(widget)

  if not widget.configPath then return end

  local f = io.open(widget.configPath, "r")

  if not f then
    return
  end

  local buffer = ""
  local values = {}

  while true do

    local chunk = io.read(f, 64)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "[^%-%d]", "")

      if line ~= "" then
        values[#values+1] = tonumber(line)
      end
    end

    if not chunk or chunk == "" then break end
  end

  io.close(f)

  -------------------------------------------------
  -- APPLY VALUES
  -------------------------------------------------

  if #values >= 7 then
    widget.maneuver1 = values[5] or 0
    widget.maneuver2 = values[6] or 0
    widget.yTarget   = values[7] or 0
  end
end

---------------------------------------------------------------------------
-- LOAD BUDGET
---------------------------------------------------------------------------

local function loadBudget(widget)

  if widget.budgetLoaded then
    return
  end

  local path = "/SCRIPTS/TOOLS/FlightProgress/Budget.txt"

  local f = io.open(path, "r")

  if not f then
    return
  end

  local buffer = ""

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer,"\n",1,true)

      if not s then break end

      local line = string.sub(buffer,1,s-1)
      buffer = string.sub(buffer,s+1)
      line = string.gsub(line,"\r","")

      -------------------------------------------------
      -- SKIP HEADER
      -------------------------------------------------

      if line ~= "" and not string.find(line,"Year",1,true) then

        local cols = {}

        for v in string.gmatch(line,"([^,]*)")
        do
          cols[#cols+1] = v
        end

        local year = tonumber(cols[1]) or 0
        local budget = tonumber(cols[2]) or 0
        local costType = cols[3] or ""
        local cost = tonumber(cols[5]) or 0

        -------------------------------------------------
        -- THIS YEAR ONLY
        -------------------------------------------------

        if year == widget.budgetYear then

          widget.budget = budget

          if costType == "N" then
            widget.costN = widget.costN + cost

          elseif costType == "R" then
            widget.costR = widget.costR + cost

          elseif costType == "M" then
            widget.costM = widget.costM + cost

          elseif costType == "S" then
            widget.costS = widget.costS + cost

          elseif costType == "O" then
            widget.costO = widget.costO + cost

          elseif costType == "C" then
            widget.costC = widget.costC + cost
          end
        end
      end
    end

    if not chunk or
       chunk == ""
    then
      break
    end
  end

  io.close(f)

  -------------------------------------------------
  -- TOTALS
  -------------------------------------------------

  widget.used =
      widget.costN
    + widget.costR
    + widget.costM
    + widget.costS
    + widget.costO
    - widget.costC

  widget.remaining =
      widget.budget
    - widget.used

  if widget.budget > 0 then

    widget.usedPct =
      (widget.used /
       widget.budget)
      * 100
  end

  widget.budgetLoaded =
    true
end

---------------------------------------------------------------------------
-- LOAD BUDGET DETAILS
---------------------------------------------------------------------------

local function loadBudgetDetails(widget)

  widget.budgetRows = {}
  widget.totalSpend = 0
  widget.totalCredit = 0

  local path =
    "/SCRIPTS/TOOLS/FlightProgress/Budget.txt"

  local f = io.open(path,"r")

  if not f then
    return
  end

  local buffer = ""

  while true do

    local chunk = io.read(f,128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s =
        string.find(buffer,"\n",1,true)

      if not s then break end

      local line = string.sub(buffer,1,s-1)
      buffer = string.sub(buffer,s+1)
      line = string.gsub(line,"\r","")

      ------------------------------------------------
      -- SKIP HEADER
      ------------------------------------------------

      if line ~= "" and not string.find(line,"Year",1,true) then

        local cols = {}

        for v in string.gmatch(line,"([^,]*)") do
          cols[#cols+1] = v
        end

        local year = tonumber(cols[1]) or 0

        ------------------------------------------------
        -- FILTER YEAR + SEARCH
        ------------------------------------------------

        local costType = cols[3] or ""
        local cost = tonumber(cols[5]) or 0
        local notes = cols[6] or ""

        ------------------------------------------------
        -- SEARCH FILTER
        ------------------------------------------------

        local matchesSearch = true

        if widget.searchText ~= "" then

          matchesSearch =
            string.find(
              string.lower(notes),
              string.lower(widget.searchText),
              1,
              true
            ) ~= nil
        end

        if year == widget.budgetYear and matchesSearch then

          local typeName = costType

          if costType=="N" then
            typeName="New Model"
          elseif costType=="R" then
            typeName="Repair"
          elseif costType=="M" then
            typeName="Maintenance"
          elseif costType=="S" then
            typeName="Spares"
          elseif costType=="O" then
            typeName="Other"
          elseif costType=="C" then
            typeName="Credit"
          end

          ------------------------------------------------
          -- TOTALS
          ------------------------------------------------

          if costType=="C" then
            widget.totalCredit =
              widget.totalCredit + cost
          else
            widget.totalSpend =
              widget.totalSpend + cost
          end

          ------------------------------------------------
          -- STORE ROW
          ------------------------------------------------

          table.insert(
            widget.budgetRows,
            {
              date = cols[4] or "",
              value = cost,
              type = typeName,
              notes = notes,
              color = costType=="C" and GREEN or RED
            }
          )
        end
      end
    end

    if not chunk or chunk == "" then
      break
    end
  end

  io.close(f)

  ------------------------------------------------
  -- SORT NEWEST FIRST
  ------------------------------------------------

  table.sort(widget.budgetRows,function(a,b)

    local ay = tonumber(string.sub(a.date,1,4)) or 0
    local am = tonumber(string.sub(a.date,6,7)) or 0
    local ad = tonumber(string.sub(a.date,9,10)) or 0
    local by = tonumber(string.sub(b.date,1,4)) or 0
    local bm = tonumber(string.sub(b.date,6,7)) or 0
    local bd = tonumber(string.sub(b.date,9,10)) or 0
    
    local da = ay*10000 + am*100 + ad
    local db = by*10000 + bm*100 + bd

    return da > db

  end)

end
---------------------------------------------------------------------------
-- DASHBOARD 1 -- FLIGHT DASHBOARD
---------------------------------------------------------------------------

local function drawDashboard1(widget)

local z = widget.zone
  local extraYear = widget.extraYear
  loadConfig(widget)

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)

  lcd.drawText(z.x + z.w/2, z.y + 8, (model.getInfo().name or "MODEL") .. " STATS", CENTER + DBLSIZE + WHITE)

  ------------------------------------------------------------------
  -- READ MANEUVERS FILE (_M)
  ------------------------------------------------------------------

if widget.fileM then

  local chunk = io.read(widget.fileM, 512)

  if not chunk or chunk == "" then

    io.close(widget.fileM)
    widget.fileM = nil
    widget.bufferM = widget.bufferM .. "\n"

  else

    widget.bufferM = widget.bufferM .. chunk

  end

  while true do

    local s = string.find(widget.bufferM, "\n", 1, true)
    if not s then break end

    local line = string.sub(widget.bufferM, 1, s-1)
    widget.bufferM = string.sub(widget.bufferM, s+1)

    line = string.gsub(line, "\r", "")

    if line ~= "" and not string.find(line, "ModelName", 1, true) then

      local cols = {}

      for v in string.gmatch(line, "([^,]*)") do
        cols[#cols+1] = v
      end

      local year = tonumber(string.match(cols[2] or "", "%d%d%d%d")) or 0
      local m = tonumber(cols[7])

      ------------------------------------------------
      -- UNIQUE MANEUVERS THIS YEAR
      ------------------------------------------------

      if year == widget.thisYear and m and m > 0 then
        widget.maneuverSet[m] = true
      end

    end
  end
end

  ------------------------------------------------------------------
  -- STREAM FILE (single pass)
  ------------------------------------------------------------------

  if widget.fileS then

    local chunk = io.read(widget.fileS, 128)

    if not chunk or chunk == "" then
      io.close(widget.fileS)
      widget.fileS = nil
      widget.bufferS = widget.bufferS .. "\n"
    else
      widget.bufferS = widget.bufferS .. chunk
    end

    while true do
      local s = string.find(widget.bufferS, "\n", 1, true)
      if not s then break end

      local line = string.sub(widget.bufferS, 1, s-1)
      widget.bufferS = string.sub(widget.bufferS, s+1)
      line = string.gsub(line, "\r", "")

      if line ~= "" and not string.find(line, "ModelName", 1, true) then

        local cols = {}
        for v in string.gmatch(line, "([^,]*)") do
          cols[#cols+1] = v
        end

        local flights = tonumber(cols[5]) or 0
        local secs    = tonumber(cols[6]) or 0
        local crash   = tonumber(cols[8]) or 0
        local target  = tonumber(cols[9]) or 0
        local year    = tonumber(string.match(cols[2] or "", "%d%d%d%d")) or 0
        local lineType = cols[10] or ""

        ----------------------------------------------------------
        -- TOTALS
        ----------------------------------------------------------

        widget.tFlights = widget.tFlights + flights
        widget.tSeconds = widget.tSeconds + secs
        widget.tCrashes = widget.tCrashes + crash

        ----------------------------------------------------------
        -- THIS / LAST YEAR
        ----------------------------------------------------------

        if year == widget.thisYear then
          widget.yFlights = widget.yFlights + flights
          widget.ySeconds = widget.ySeconds + secs
          widget.yCrashes = widget.yCrashes + crash
          
        end

        if year == widget.lastYear then
          widget.pFlights = widget.pFlights + flights
          widget.pSeconds = widget.pSeconds + secs
          widget.pCrashes = widget.pCrashes + crash
          widget.pTarget  = target
        end

        ----------------------------------------------------------
        -- MANEUVERS COUNT THIS YEAR
        ---------------------------------------------------------- 
        if year == widget.thisYear then

        local m = tonumber(cols[7])
        if m and m > 0 then
          widget.maneuverSet[m] = true
        end
        end
        ----------------------------------------------------------
        -- STORE PER YEAR
        ----------------------------------------------------------

        local ys = widget.yearStats[year]
        if not ys then
          ys = {f=0,s=0,c=0,t=0}
          widget.yearStats[year] = ys
        end

        ys.f = ys.f + flights
        ys.s = ys.s + secs
        ys.c = ys.c + crash
        ys.t = target
      end
    end
  end

 --------------------------------------------------
  -- READ OPERATIONS FILE (_O)
 --------------------------------------------------

if widget.fileO then

  local chunk = io.read(widget.fileO, 128)

  if not chunk or chunk == "" then
    io.close(widget.fileO)
    widget.fileO = nil
    widget.bufferO = widget.bufferO .. "\n"
  else
    widget.bufferO = widget.bufferO .. chunk
  end

  while true do

    local s = string.find(widget.bufferO, "\n", 1, true)
    if not s then break end

    local line = string.sub(widget.bufferO, 1, s-1)
    widget.bufferO = string.sub(widget.bufferO, s+1)

    line = string.gsub(line, "\r", "")

    if line ~= "" and not string.find(line, "ModelName", 1, true) then

      local cols = {}

      for v in string.gmatch(line, "([^,]*)") do
        cols[#cols+1] = v
      end

      local year = tonumber(string.match(cols[2] or "", "%d%d%d%d")) or 0
      local lineType = cols[10] or ""

      --------------------------------------------------
      -- HISTORY
      --------------------------------------------------

      if lineType == "H" then

        local flights = tonumber(cols[5]) or 0
        local secs    = tonumber(cols[6]) or 0
        local crash   = tonumber(cols[8]) or 0
        local target  = tonumber(cols[9]) or 0

        widget.tFlights = widget.tFlights + flights
        widget.tSeconds = widget.tSeconds + secs
        widget.tCrashes = widget.tCrashes + crash

        if year == widget.thisYear then
          widget.yFlights = widget.yFlights + flights
          widget.ySeconds = widget.ySeconds + secs
          widget.yCrashes = widget.yCrashes + crash 
          
        end

        if year == widget.lastYear then
          widget.pFlights = widget.pFlights + flights
          widget.pSeconds = widget.pSeconds + secs
          widget.pCrashes = widget.pCrashes + crash
          widget.pTarget  = target
        end

        --------------------------------------------------
        -- STORE HISTORY YEAR DATA
        --------------------------------------------------

        local ys = widget.yearStats[year]

        if not ys then
          ys = {f=0,s=0,c=0,t=0}
          widget.yearStats[year] = ys
        end

        ys.f = ys.f + flights
        ys.s = ys.s + secs
        ys.c = ys.c + crash
        ys.t = target

      end

      --------------------------------------------------
      -- CRASH
      --------------------------------------------------

      if lineType == "C" then

        widget.tCrashes = widget.tCrashes + 1

        if year == widget.thisYear then
          widget.yCrashes = widget.yCrashes + 1
        end

        if year == widget.lastYear then
          widget.pCrashes = widget.pCrashes + 1
        end

      end

      --------------------------------------------------
      -- SERVICE
      --------------------------------------------------

      if lineType == "S" then

        widget.tServices = widget.tServices + 1

        if year == widget.thisYear then
          widget.yServices = widget.yServices + 1
        end

        if year == widget.lastYear then
          widget.pServices = widget.pServices + 1
        end

      end

    end
  end
end

  --------------------------------------------------
  -- READ MAIN FILE (LAST FLIGHT DATE)
  --------------------------------------------------

if not widget.doneMain and widget.fileMain then

  local chunk = io.read(widget.fileMain, 1024)

  if not chunk or chunk == "" then

    io.close(widget.fileMain)
    widget.fileMain = nil
    widget.doneMain = true

  else

    widget.bufferMain = widget.bufferMain .. chunk

  end

  while true do

    local s = string.find(widget.bufferMain,"\n",1,true)
    if not s then break end

    local line = string.sub(widget.bufferMain,1,s-1)
    widget.bufferMain = string.sub(widget.bufferMain,s+1)

    line = string.gsub(line,"\r","")

    if line ~= "" and not string.find(line,"ModelName",1,true) then

      local cols={}

      for v in string.gmatch(line,"([^,]*)") do
        cols[#cols+1]=v
      end

      widget.lastFlightDate = cols[2] or ""

    end
  end
end

  ------------------------------------------------------------------
  -- COUNT MANEUVERS ONCE
  ------------------------------------------------------------------
  widget.maneuverCount = 0

  for _ in pairs(widget.maneuverSet) do
    widget.maneuverCount = widget.maneuverCount + 1
  end
  ------------------------------------------------------------------
  -- LOOKUP EXTRA YEAR
  ------------------------------------------------------------------

  local e = extraYear and widget.yearStats[extraYear]

  ------------------------------------------------------------------
  -- DRAW TABLE
  ------------------------------------------------------------------

  local left  = z.x + 10
  local col1  = z.x + 130
  local col2  = z.x + 180
  local col3  = z.x + 230
  local col4  = z.x + 280

  local y = z.y + 52
  local step = 18

  lcd.drawText(col1, y, "Total", SMLSIZE + YELLOW)
  lcd.drawText(col2, y, tostring(widget.thisYear), SMLSIZE + YELLOW)
  lcd.drawText(col3, y, tostring(widget.lastYear), SMLSIZE + YELLOW)
  if extraYear then lcd.drawText(col4, y, tostring(extraYear), SMLSIZE + YELLOW) end

  y = y + step + 4
  lcd.drawText(left, y, "Flight Target:", SMLSIZE + WHITE)
  lcd.drawText(col2, y, widget.yTarget, SMLSIZE + WHITE)
  lcd.drawText(col3, y, widget.pTarget, SMLSIZE + WHITE)
  if extraYear then lcd.drawText(col4, y, e and e.t or "-", SMLSIZE + WHITE) end

  y = y + step
  lcd.drawText(left, y, "Flight Count:", SMLSIZE + WHITE)
  lcd.drawText(col1, y, widget.tFlights, SMLSIZE + WHITE)
  lcd.drawText(col2, y, widget.yFlights, SMLSIZE + WHITE)
  lcd.drawText(col3, y, widget.pFlights, SMLSIZE + WHITE)
  if extraYear then lcd.drawText(col4, y, e and e.f or "-", SMLSIZE + WHITE) end

  y = y + step
  lcd.drawText(left, y, "Flight Duration (H):", SMLSIZE + WHITE)
  lcd.drawText(col1, y, string.format("%.1f", widget.tSeconds/3600), SMLSIZE + WHITE)
  lcd.drawText(col2, y, string.format("%.1f", widget.ySeconds/3600), SMLSIZE + WHITE)
  lcd.drawText(col3, y, string.format("%.1f", widget.pSeconds/3600), SMLSIZE + WHITE)
  if extraYear then lcd.drawText(col4, y, e and string.format("%.1f", e.s/3600) or "-", SMLSIZE + WHITE) end

  y = y + step
  lcd.drawText(left, y, "Crashes:", SMLSIZE + WHITE)
  lcd.drawText(col1, y, widget.tCrashes, SMLSIZE + WHITE)
  lcd.drawText(col2, y, widget.yCrashes, SMLSIZE + WHITE)
  lcd.drawText(col3, y, widget.pCrashes, SMLSIZE + WHITE)
  if extraYear then lcd.drawText(col4, y, e and e.c or "-", SMLSIZE + WHITE) end
  
  y = y + step
  lcd.drawText(left, y, "Services:", SMLSIZE + WHITE)
  lcd.drawText(col1, y, widget.tServices, SMLSIZE + WHITE)
  lcd.drawText(col2, y, widget.yServices, SMLSIZE + WHITE)
  lcd.drawText(col3, y, widget.pServices, SMLSIZE + WHITE)
  if extraYear then lcd.drawText(col4, y, e and (e.svc or 0) or "-", SMLSIZE + WHITE) end


------------------------------------------------------------------
-- BAR CHART
------------------------------------------------------------------

local x0 = z.x + z.w - 120
local baseY = z.y + 150
local barW = 30
local gap = 0
local maxH = 90

----------------------------------------------------------
-- build bars dynamically (2 or 3)
----------------------------------------------------------

local bars = {
  {year = widget.thisYear, v = widget.yFlights},
  {year = widget.lastYear, v = widget.pFlights}
}

if extraYear then
  local extraFlights = widget.yearStats[extraYear] and widget.yearStats[extraYear].f or 0
  table.insert(bars, {year = extraYear, v = extraFlights})
end

----------------------------------------------------------
-- sort by value
----------------------------------------------------------

table.sort(bars, function(a,b) return a.v > b.v end)

local colors = { DARKGREEN, ORANGE, DARKRED }

----------------------------------------------------------
-- scale to highest
----------------------------------------------------------

local maxVal = bars[1].v
if maxVal == 0 then maxVal = 1 end

----------------------------------------------------------
-- draw bars
----------------------------------------------------------

for i=1,#bars do
  local b = bars[i]

  local height = math.floor((b.v / maxVal) * maxH)

  local x = x0 + (i-1)*(barW + gap)
  local yTop = baseY - height

  lcd.drawFilledRectangle(x, yTop, barW, height, colors[i])

  -- year label
  lcd.drawText(x + barW/2, baseY + 4, tostring(b.year), SMLSIZE + CENTER)
end

----------------------------------------------------------
-- TARGET ACHIEVED CIRCLE
----------------------------------------------------------
  local startX = z.x + z.w - 115
  local cBaseY = z.y + 210
  local rBigF, spacing = 53, 0
  local rBigCCX  = startX + rBigF
  
  local tar = (widget.yTarget > 0) and (widget.yFlights / widget.yTarget * 100) or 0

  lcd.drawFilledCircle(rBigCCX, cBaseY, rBigF, ORANGE)
  lcd.drawCircle(rBigCCX, cBaseY, rBigF, WHITE)
  lcd.drawText(rBigCCX, cBaseY+15, "Target", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigCCX, cBaseY+28 , "Achieved", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigCCX, cBaseY-25, string.format("%.1f%%", tar), DBLSIZE + WHITE + CENTER)

----------------------------------------------------------
-- CRASHES CIRCLE
----------------------------------------------------------
  local startX = z.x + z.w - 210
  local cBaseY = z.y + 210
  local rBigCR, spacing = 50, 0
  local rBigCRCX  = startX + rBigCR
  
  local crashes = (widget.yCrashes > 0) and (widget.yCrashes / widget.yFlights * 100) or 0

  lcd.drawFilledCircle(rBigCRCX, cBaseY, rBigCR, ORANGE)
  lcd.drawCircle(rBigCRCX, cBaseY, rBigCR, WHITE)
  lcd.drawText(rBigCRCX, cBaseY+15, "Crash %", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigCRCX, cBaseY+28, "YTD", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigCRCX, cBaseY-25, string.format("%.1f%%", crashes), DBLSIZE + WHITE + CENTER)
----------------------------------------------------------
-- MANEUVERS COUNT CIRCLE
----------------------------------------------------------
  local startX = z.x + z.w - 300
  local cBaseY = z.y + 210
  local rBigM, spacing = 47, 0
  local rBigMCX  = startX + rBigM
  
  local maneuvers = widget.maneuverCount or 0

  lcd.drawFilledCircle(rBigMCX, cBaseY, rBigM, ORANGE)
  lcd.drawCircle(rBigMCX, cBaseY, rBigM, WHITE)
  lcd.drawText(rBigMCX, cBaseY+15, "Maneuvers", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigMCX, cBaseY+28 , "YTD", SMLSIZE + BLACK + CENTER)
  lcd.drawText(rBigMCX, cBaseY-25, maneuvers, DBLSIZE + WHITE + CENTER)

----------------------------------------------------------
-- LAST FLIGHT DATE
----------------------------------------------------------
  local boxX = z.x + 10
  local boxY = z.y + z.h - 70 

  local lastDateText = widget.lastFlightDate or "-"

  lcd.drawText(boxX, boxY - 20, "Last Flight Date:", SMLSIZE + YELLOW)
  lcd.drawText(boxX + 95, boxY - 20, lastDateText, SMLSIZE + WHITE)

----------------------------------------------------------
-- MANEUVERS IN PROGRESS (GV6 FM4/FM2)
---------------------------------------------------------- 

  local m1 = widget.maneuver1
  local m2 = widget.maneuver2

  local name1 = maneuverNames[m1 or 0] or "-"
  local name2 = maneuverNames[m2 or 0] or "-"

  lcd.drawText(boxX, boxY, "Maneuvers In Progress", SMLSIZE + YELLOW)

  lcd.drawText(boxX,     boxY + 16, "M1:", SMLSIZE + WHITE)
  lcd.drawText(boxX+25,  boxY + 16, name1, SMLSIZE + WHITE)

  lcd.drawText(boxX,     boxY + 32, "M2:", SMLSIZE + WHITE)
  lcd.drawText(boxX+25,  boxY + 32, name2, SMLSIZE + WHITE)

end

---------------------------------------------------------------------------
-- DASHBOARD 2 -- BUDGET SUMMARY
---------------------------------------------------------------------------

local function drawDashboard2(widget)

  local z = widget.zone

  loadBudget(widget)

  lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)

  lcd.drawText(z.x + z.w/2,z.y + 8,"BUDGET SUMMARY",CENTER + DBLSIZE + WHITE)
  lcd.drawText(z.x + z.w/2,z.y + 38,tostring(widget.budgetYear),CENTER + MIDSIZE + YELLOW)
  
  ------------------------------------------------
  -- PROGRESS BAR
  -------------------------------------------------

  local barX = z.x + 35
  local barY = z.y + 72
  local barW = z.w - 70
  local barH = 32

  local usedPct = tonumber(widget.usedPct) or 0
  local pct = math.min(tonumber(usedPct) or 0,100)
  local usedW = math.floor((pct / 100) * barW)

  lcd.drawRectangle(barX,barY,barW,barH,WHITE)

  if usedW > 0 then
    lcd.drawFilledRectangle(barX+1,barY+1,usedW-2,barH-2,RED)
  end

  if usedW < barW then
    lcd.drawFilledRectangle(barX+usedW,barY+1,barW-usedW-1,barH-2,GREEN)
  end

  local budgetText = ""

    if usedPct <= 100 then
      budgetText = string.format("%.1f%% Used",usedPct)
    else
      budgetText = string.format("%.1f%% Over Budget",usedPct - 100)
    end

  lcd.drawText(z.x + z.w/2,z.y + 75,budgetText,CENTER + MIDSIZE + WHITE)

  -------------------------------------------------
  -- SUMMARY VALUES
  -------------------------------------------------

  lcd.drawText(z.x + 40,z.y + 115,"Budget:",SMLSIZE + YELLOW + LEFT)
  lcd.drawText(z.x + 88,z.y + 115,tostring(widget.budget),SMLSIZE + WHITE + LEFT)

  lcd.drawText(z.x + z.w/2 - 20,z.y + 115,"Used:",SMLSIZE + YELLOW + CENTER)
  lcd.drawText(z.x + z.w/2 + 13,z.y + 115,tostring(widget.used),SMLSIZE + WHITE + CENTER)

  lcd.drawText(z.x + z.w - 65,z.y + 115,"Remaining:",SMLSIZE + YELLOW + RIGHT)
  lcd.drawText(z.x + z.w - 40,z.y + 115,tostring(widget.remaining),SMLSIZE + WHITE + RIGHT)

  ----------------------------------------------------------
  -- CATEGORY BAR CHART
  ----------------------------------------------------------

  local categories = {
    {name="New Model", value=widget.costN or 0, color=YELLOW},
    {name="Repair", value=widget.costR or 0, color=RED},
    {name="Maintenance", value=widget.costM or 0, color=BLUE},
    {name="Spares", value=widget.costS or 0, color=GREEN},
    {name="Other", value=widget.costO or 0, color=ORANGE}
  }

  ----------------------------------------------------------
  -- SCALE
  ----------------------------------------------------------

  local maxVal = 0

  for i=1,#categories do
    if categories[i].value > maxVal then
      maxVal = categories[i].value
    end
  end

  if maxVal == 0 then
    maxVal = 1
  end

  ----------------------------------------------------------
  -- DRAW BARS
  ----------------------------------------------------------

  local count = #categories
  local maxH = 75
  local bottomY = z.y + z.h - 35

  local totalWidth = z.w - 40
  local barW = math.floor(totalWidth / count)
  local startX = z.x + 20

  for i=1,count do

    local cat = categories[i]
    local height = math.floor((cat.value / maxVal) * maxH)

    local x = startX + (i-1) * barW
    local yTop = bottomY - height

    lcd.drawFilledRectangle(x,yTop,barW-6,height,cat.color)

    ----------------------------------------------------------
    -- VALUE ABOVE BAR
    ----------------------------------------------------------

    lcd.drawText(x + (barW-6)/2,yTop - 16,tostring(cat.value),SMLSIZE + CENTER + cat.color)

    ----------------------------------------------------------
    -- CATEGORY LABEL
    ----------------------------------------------------------

    lcd.drawText(x + (barW-6)/2,bottomY + 6,cat.name,SMLSIZE + CENTER + cat.color)

  end
end

---------------------------------------------------------------------------
-- DASHBOARD 3 -- BUDGET DETAILS
---------------------------------------------------------------------------

local function drawDashboard3(widget)

  local z = widget.zone

  loadBudgetDetails(widget)

  lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
  lcd.drawText(z.x + z.w/2,z.y + 8,"BUDGET DETAILS",CENTER + DBLSIZE + WHITE)
  lcd.drawText(z.x + z.w/2,z.y + 38,tostring(widget.budgetYear),CENTER + MIDSIZE + YELLOW)

  ------------------------------------------------
  -- TOTALS
  ------------------------------------------------

  lcd.drawText(z.x + 40,z.y + 78,"Total Spend: "..widget.totalSpend,SMLSIZE + YELLOW)
  lcd.drawText(z.x + z.w - 150,z.y + 78,"Total Credit: "..widget.totalCredit,SMLSIZE + YELLOW)

  ------------------------------------------------
  -- HEADERS
  ------------------------------------------------

  lcd.drawText(z.x + 40,z.y + 110,"Date",SMLSIZE + WHITE)
  lcd.drawText(z.x + 140,z.y + 110,"Value",SMLSIZE + WHITE)
  lcd.drawText(z.x + 200,z.y + 110,"Type",SMLSIZE + WHITE)
  lcd.drawText(z.x + 300,z.y + 110,"Notes",SMLSIZE + WHITE)

  ------------------------------------------------
  -- ROWS
  ------------------------------------------------

  local visibleRows = 7
  local rowY = z.y + 130
  local step = 18

  for i=0,visibleRows-1 do

    local idx =
      widget.budgetScroll + i

    local row =
      widget.budgetRows[idx]

    if row then

      lcd.drawText(z.x + 40,rowY + i*step,row.date,SMLSIZE + row.color)
      lcd.drawText(z.x + 140,rowY + i*step,tostring(row.value),SMLSIZE + row.color)
      lcd.drawText(z.x + 200,rowY + i*step,row.type,SMLSIZE + row.color)
      lcd.drawText(z.x + 300,rowY + i*step,row.notes,SMLSIZE + row.color)

    end
  end

end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)

  if not widget.scrollInit then

    update(widget,widget.options)

    widget.scrollInit =
      true
  end

  local slider = getValue("ls") or 0

  local dashboard

  if slider < -30 then
    dashboard = 1
  elseif slider < 30 then
    dashboard = 2
  else
    dashboard = 3
  end

  ------------------------------------------------
  -- DASHBOARD 3 SCROLL
  ------------------------------------------------

  if dashboard == 3 and
     widget.scrollSwitch
  then

    local scrollValue =
      getValue(widget.scrollSwitch) or 0

    local upValue =
      getValue(widget.scrollUpPos) or 0

    local downValue =
      getValue(widget.scrollDownPos) or 0

    ------------------------------------------------
    -- SCROLL BUTTON PRESS
    ------------------------------------------------

    if scrollValue > 500 and
      widget.lastScrollValue <= 500
    then

      ------------------------------------------------
      -- SA DOWN
      ------------------------------------------------

      if downValue > 500 then

        if widget.budgetScroll <
           math.max(
             1,
             #widget.budgetRows - 6
           )
        then

          widget.budgetScroll =
            widget.budgetScroll + 1
        end
      end

      ------------------------------------------------
      -- SA UP
      ------------------------------------------------

      if upValue < -500 then

        if widget.budgetScroll > 1 then

          widget.budgetScroll =
            widget.budgetScroll - 1
        end
      end
    end

    widget.lastScrollValue =
      scrollValue
  end

  ------------------------------------------------
  -- DRAW DASHBOARD
  ------------------------------------------------

  if dashboard == 1 then
    drawDashboard1(widget)

  elseif dashboard == 2 then
    drawDashboard2(widget)

  elseif dashboard == 3 then
    drawDashboard3(widget)
  end
  
end
---------------------------------------------------------------------------
return {
  name = name,
  create = create,
  update = update,
  refresh = refresh,
  options = options
}
