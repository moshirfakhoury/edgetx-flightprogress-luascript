---------------------------------------------------------------------------
-- MODEL COUNT COMPARISON (STREAMING VERSION) V2.1
-- Created by Moshir Fakhoury (Flywithmoshirrc)
-- Last Updated 11/09/2026 
-- Removed the use of _S file, widget now only reads main and _O files
---------------------------------------------------------------------------

local name = "fltprgW2"

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "Year", STRING, "" },
  { "M1", STRING, "" },
  { "M2", STRING, "" },
  { "M3", STRING, "" },
  { "M4", STRING, "" },
  { "M5", STRING, "" },
  { "M6", STRING, "" },
  { "M7", STRING, "" },
  { "M8", STRING, "" },
  { "M9", STRING, "" }
}

---------------------------------------------------------------------------
-- FIXED COLOURS
---------------------------------------------------------------------------

local slotColors = {
  DARKGREEN,
  ORANGE,
  DARKRED,
  YELLOW,
  BLUE,
  GREY,
  DARKBROWN,
  WHITE,
  RED
}

local rebuild

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

local function create(zone, opts)

  local w = {
    zone = zone,
    options = opts or {},
    models = {},         -- finished model results
    weekly = {},
    monthly = {},
    monthlyModel = {},
    calendar = {},
    firstFlightDate = nil,
    queue = {},          -- models to parse
    active = nil,        -- currently parsing model
    fileMain = nil,
    bufferMain = "",
    fileO = nil,
    bufferO = "",
    filterYear = nil,
    done = false,
    calendarYear = nil,
    calendarMonth = nil,
    calendarLastCh1 = 0
  }

  rebuild(w)
  return w
end

---------------------------------------------------------------------------
-- BUILD QUEUE (when options change)
---------------------------------------------------------------------------

  rebuild = function(widget)

  widget.models = {}
  widget.queue = {}
  widget.active = nil
  widget.done = false
  widget.fileMain = nil
  widget.bufferMain = ""
  widget.fileO = nil
  widget.bufferO = ""
  widget.weekly = {}
  widget.monthly = {}
  widget.monthlyModel = {}
  widget.calendar = {}
  widget.firstFlightDate = nil  

  local rawYear = widget.options["Year"]
  widget.filterYear = nil

  if rawYear and rawYear ~= "" then
    widget.filterYear = tonumber(string.match(rawYear, "%d%d%d%d"))
  end

  for i = 1,9 do
    local key = "M"..i
    local modelName = widget.options[key]

    if modelName and modelName ~= "" then
      widget.queue[#widget.queue+1] = {
        name = modelName,
        color = slotColors[i],
        value = 0
      }
    end
  end
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------

local function update(widget, opts)
  widget.options = opts
  rebuild(widget)
end

---------------------------------------------------------------------------
-- STREAM PARSER (runs gradually)
---------------------------------------------------------------------------

local function process(widget)

  -- If no active file, open next in queue
  if not widget.active then

    if #widget.queue == 0 then
      widget.done = true
      return
    end

    widget.active = table.remove(widget.queue, 1)

    widget.calendar = {}
    widget.active.calendar = {}
    widget.active.firstFlightDate = nil

    local base = "/SCRIPTS/TOOLS/FlightProgress/" .. widget.active.name

    widget.fileO = io.open(base .. "_O.txt", "r")
    widget.bufferO = ""

    widget.fileMain = io.open(base .. ".txt", "r")

    if not widget.fileMain and not widget.fileO then
      widget.active = nil
    end

    return
  end

--------------------------------------------------
-- READ OPERATIONS FILE (_O)
--------------------------------------------------

if widget.fileO then

  local chunk = io.read(widget.fileO, 256)

  if not chunk or chunk == "" then
    io.close(widget.fileO)
    widget.fileO = nil
    widget.bufferO = widget.bufferO .. "\n"
  else
    widget.bufferO = widget.bufferO .. chunk
  end

  while true do

    local s = string.find(widget.bufferO, "\n", 1, true)
    if not s then break end

    local line = string.sub(widget.bufferO, 1, s-1)
    widget.bufferO = string.sub(widget.bufferO, s+1)

    line = string.gsub(line, "\r", "")

    if line ~= "" and not string.find(line, "ModelName", 1, true) then

      local cols = {}

      for v in string.gmatch(line, "([^,]*)") do
        cols[#cols+1] = v
      end

      local flights = tonumber(cols[5]) or 0
      local flightSeconds = tonumber(cols[6]) or 0
      local dateStr = cols[2] or ""

      local year  = tonumber(string.match(dateStr, "%d%d%d%d")) or 0
      local month = tonumber(string.match(dateStr, "%d%d%d%d%-(%d%d)")) or 0
      local day   = tonumber(string.match(dateStr, "%d%d%d%d%-%d%d%-(%d%d)")) or 0
      local lineType = cols[10] or ""

      if widget.filterYear == nil or year == widget.filterYear then
        if month >= 1 and month <= 12 then
          if not widget.active.monthlySeconds then
            widget.active.monthlySeconds = {}
          end

          widget.active.monthlySeconds[month] =
            (widget.active.monthlySeconds[month] or 0) + flightSeconds
        end
      end

      if lineType == "H" then

        if widget.filterYear == nil or year == widget.filterYear then
          widget.active.value = widget.active.value + flights
        end
        
--------------------------------------------------
-- MONTHLY TOTALS
--------------------------------------------------

if widget.filterYear == nil or year == widget.filterYear then
  if month >= 1 and month <= 12 then
    widget.monthly[month] = (widget.monthly[month] or 0) + flights
  end
end

--------------------------------------------------
-- MONTHLY MODEL TOTALS
--------------------------------------------------
if widget.filterYear == nil or year == widget.filterYear then

  if month >= 1 and month <= 12 then

    if not widget.monthlyModel[widget.active.name] then
      widget.monthlyModel[widget.active.name] = {}
    end

    widget.monthlyModel[widget.active.name][month] =
      (widget.monthlyModel[widget.active.name][month] or 0) + flights

  end
end
--------------------------------------------------
-- WEEKLY TOTALS (Sunday to Saturday)
--------------------------------------------------

if (widget.filterYear == nil or year == widget.filterYear)
   and year > 0 and month > 0 and day > 0 then

  local mdays = {31,28,31,30,31,30,31,31,30,31,30,31}

  if (year % 4 == 0 and year % 100 ~= 0) or (year % 400 == 0) then
    mdays[2] = 29
  end

  local doy = day
  for i = 1, month-1 do
    doy = doy + mdays[i]
  end

  local m = month
  local y = year

  if m < 3 then
    m = m + 12
    y = y - 1
  end

  local K = y % 100
  local J = math.floor(y / 100)

  local h = (day + math.floor((13*(m+1))/5) + K + math.floor(K/4) + math.floor(J/4) + 5*J) % 7

  local wday = (h + 6) % 7 -- 0 = Sunday

  local sundayDOY = doy - wday
  if sundayDOY < 1 then sundayDOY = 1 end

  local m2 = 1
  while sundayDOY > mdays[m2] do
    sundayDOY = sundayDOY - mdays[m2]
    m2 = m2 + 1
  end

  local d2 = sundayDOY

  local key = string.format("%04d-%02d-%02d", year, m2, d2)

  widget.weekly[key] = (widget.weekly[key] or 0) + flights

end

      end

    end
  end
end

--------------------------------------------------
-- READ MAIN FILE
--------------------------------------------------

if widget.fileMain then

  local chunk = io.read(widget.fileMain, 256)

  if not chunk or chunk == "" then
    io.close(widget.fileMain)
    widget.fileMain = nil
    widget.bufferMain = widget.bufferMain .. "\n"
  else
    widget.bufferMain = widget.bufferMain .. chunk
  end

  while true do

    local s = string.find(widget.bufferMain, "\n", 1, true)
    if not s then break end

    local line = string.sub(widget.bufferMain, 1, s-1)
    widget.bufferMain = string.sub(widget.bufferMain, s+1)

    line = string.gsub(line, "\r", "")

    if line ~= "" and not string.find(line, "ModelName", 1, true) then

      local cols = {}

      for v in string.gmatch(line, "([^,]*)") do
        cols[#cols+1] = v
      end

      local flights = tonumber(cols[5]) or 0
      local flightSeconds = tonumber(cols[6]) or 0
      local dateStr = cols[2] or ""

      local year  = tonumber(string.match(dateStr, "%d%d%d%d")) or 0
      local month = tonumber(string.match(dateStr, "%d%d%d%d%-(%d%d)")) or 0
      local day   = tonumber(string.match(dateStr, "%d%d%d%d%-%d%d%-(%d%d)")) or 0

      if widget.filterYear == nil or year == widget.filterYear then
        if month >= 1 and month <= 12 then
          if not widget.active.monthlySeconds then
            widget.active.monthlySeconds = {}
          end

          widget.active.monthlySeconds[month] =
            (widget.active.monthlySeconds[month] or 0) + flightSeconds
        end
      end

      if flights == 1 and year > 0 and month > 0 and day > 0 then
        local key = string.format("%04d-%02d-%02d", year, month, day)
       
        widget.active.calendar[key] = (widget.active.calendar[key] or 0) + 1

        if not widget.active.firstFlightDate then
          widget.active.firstFlightDate = dateStr
        end
      end

      if widget.filterYear == nil or year == widget.filterYear then
        widget.active.value = widget.active.value + flights
      end
      
--------------------------------------------------
-- MONTHLY TOTALS
--------------------------------------------------

if widget.filterYear == nil or year == widget.filterYear then
  if month >= 1 and month <= 12 then
    widget.monthly[month] = (widget.monthly[month] or 0) + flights
  end
end

--------------------------------------------------
-- MONTHLY MODEL TOTALS
--------------------------------------------------
if widget.filterYear == nil or year == widget.filterYear then

  if month >= 1 and month <= 12 then

    if not widget.monthlyModel[widget.active.name] then
      widget.monthlyModel[widget.active.name] = {}
    end

    widget.monthlyModel[widget.active.name][month] =
      (widget.monthlyModel[widget.active.name][month] or 0) + flights

  end
end

--------------------------------------------------
-- WEEKLY TOTALS (Sunday to Saturday)
--------------------------------------------------

if (widget.filterYear == nil or year == widget.filterYear)
   and year > 0 and month > 0 and day > 0 then

  local mdays = {31,28,31,30,31,30,31,31,30,31,30,31}

  if (year % 4 == 0 and year % 100 ~= 0) or (year % 400 == 0) then
    mdays[2] = 29
  end

  local doy = day
  for i = 1, month-1 do
    doy = doy + mdays[i]
  end

  local m = month
  local y = year

  if m < 3 then
    m = m + 12
    y = y - 1
  end

  local K = y % 100
  local J = math.floor(y / 100)

  local h = (day + math.floor((13*(m+1))/5) + K + math.floor(K/4) + math.floor(J/4) + 5*J) % 7

  local wday = (h + 6) % 7 -- 0 = Sunday

  local sundayDOY = doy - wday
  if sundayDOY < 1 then sundayDOY = 1 end

  local m2 = 1
  while sundayDOY > mdays[m2] do
    sundayDOY = sundayDOY - mdays[m2]
    m2 = m2 + 1
  end

  local d2 = sundayDOY

  local key = string.format("%04d-%02d-%02d", year, m2, d2)

  widget.weekly[key] = (widget.weekly[key] or 0) + flights

end


    end
  end
end

--------------------------------------------------
-- FINISHED MODEL
--------------------------------------------------

if not widget.fileMain and not widget.fileO then
  widget.active.calendar = widget.active.calendar or {}
  widget.active.firstFlightDate = widget.active.firstFlightDate

  widget.models[#widget.models+1] = widget.active
  widget.active = nil
end

end

---------------------------------------------------------------------------
-- DASHBOARD 1 -- MODEL COMPARISON
---------------------------------------------------------------------------
local function drawDashboard1(widget)

local z = widget.zone

  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)

    return
  end

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)

  lcd.drawText(z.x + z.w/2, z.y + 8, "MODEL COMPARISON", CENTER + DBLSIZE + WHITE)
  
  local subtitle
  if widget.filterYear == nil then
    subtitle = "Lifetime Total"
  else
    subtitle = tostring(widget.filterYear)
  end

  lcd.drawText(z.x + z.w/2, z.y + 40, subtitle, CENTER + SMLSIZE + BOLD + WHITE)

  if #widget.models == 0 then
    return
  end

  ----------------------------------------------------------
  -- SCALE
  ----------------------------------------------------------

  local maxVal = 0
  for i=1,#widget.models do
    if widget.models[i].value > maxVal then
      maxVal = widget.models[i].value
    end
  end
  if maxVal == 0 then maxVal = 1 end

  ----------------------------------------------------------
  -- DRAW BARS
  ----------------------------------------------------------

  local count = #widget.models
  local maxH = 120
  local bottomY = z.y + z.h - 40

  local totalWidth = z.w - 40
  local barW = math.floor(totalWidth / count)
  local startX = z.x + 20

  for i=1,count do

    local model = widget.models[i]
    local height = math.floor((model.value / maxVal) * maxH)

    local x = startX + (i-1)*barW
    local yTop = bottomY - height

    lcd.drawFilledRectangle(x, yTop, barW-4, height, model.color)
    lcd.drawText(x + (barW-4)/2, yTop - 22, tostring(model.value), SMLSIZE + CENTER + model.color) -- flight count above bar
    
  -- alternate vertical positioning model names
  local nameY

  if i % 2 == 0 then
    nameY = bottomY + 18   -- lower line
  else
    nameY = bottomY + 6    -- upper line
  end

  lcd.drawText(x + (barW-4)/2, nameY, model.name,SMLSIZE + CENTER + model.color)

  end


end

---------------------------------------------------------------------------
-- DASHBOARD 2 -- WEEKLY MONTHLY COMPARISON
---------------------------------------------------------------------------
local function drawDashboard2(widget)

  local z = widget.zone

  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)

    return
  end

  local title = "FLYING TRENDS"

  if widget.filterYear ~= nil then
    title = title .. " " .. tostring(widget.filterYear)
  end

  lcd.drawText(z.x + z.w/2, z.y + 8, title, CENTER + MIDSIZE + WHITE)
  lcd.drawText(z.x + z.w/2, z.y + 45, "Flights - Last 5 Weeks", CENTER + SMLSIZE + LIGHTBROWN)

  --------------------------------------------------
  -- LAST 5 WEEKS
  --------------------------------------------------

local weeks = {}

for k,v in pairs(widget.weekly) do
  weeks[#weeks+1] = {key=k, value=v}
end

table.sort(weeks, function(a,b) return a.key > b.key end)

local count = math.min(5, #weeks)

for i=1,count do
  local w = weeks[i]

  local spacing = z.w / (count + 1)
  local x = spacing * i

  lcd.drawText(x, z.y + 60, tostring(w.value), DBLSIZE + CENTER + WHITE)
  lcd.drawText(x, z.y + 90, w.key, SMLSIZE + CENTER + YELLOW)

end


  --------------------------------------------------
  -- TOTAL FLIGHTS LABEL
  --------------------------------------------------

  local totalFlights = 0

  for i=1,12 do
    totalFlights = totalFlights + (widget.monthly[i] or 0)
  end

  local text

  if widget.filterYear ~= nil then
    text = totalFlights .. " Flights in " .. widget.filterYear
  else
    text = "Total Flights " .. totalFlights
  end

  lcd.drawText(z.x + z.w/2, z.y + 120, text, SMLSIZE + CENTER + LIGHTBROWN)

  --------------------------------------------------
  -- MONTH GRAPH
  --------------------------------------------------

  local maxVal = 0
  for i=1,12 do
    local v = widget.monthly[i] or 0
    if v > maxVal then maxVal = v end
  end
  if maxVal == 0 then maxVal = 1 end

  local barW = (z.w - 40) / 12
  local baseY = z.y + z.h - 40

  local monthNames = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}

  for i=1,12 do

    local v = widget.monthly[i] or 0
    local h = math.floor((v / maxVal) * 80)

    local x = z.x + 20 + (i-1)*barW

    local color = slotColors[((i-1) % #slotColors) + 1]

    local yTop = baseY - h

    lcd.drawFilledRectangle(x, yTop, barW-2, h, color)

    lcd.drawText(x + (barW-2)/2, yTop - 18, tostring(v), SMLSIZE + CENTER + WHITE)
    lcd.drawText(x + barW/2, baseY + 5, monthNames[i], SMLSIZE + CENTER + YELLOW)


  end

end

---------------------------------------------------------------------------
-- Y AXIS MAX FUNCTION FOR DASHBOARD 3
---------------------------------------------------------------------------
local function niceMax(value)

  if value <= 10 then
    return math.ceil(value)
  elseif value <= 50 then
    return math.ceil(value / 5) * 5
  elseif value <= 100 then
    return math.ceil(value / 10) * 10
  elseif value <= 250 then
    return math.ceil(value / 10) * 10
  elseif value <= 500 then
    return math.ceil(value / 25) * 25
  else
    return math.ceil(value / 50) * 50
  end

end
---------------------------------------------------------------------------
-- DASHBOARD 3 -- MONTHLY MODEL COMPARISON GRAPH
---------------------------------------------------------------------------
local function drawDashboard3(widget)

  local z = widget.zone

  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)

    return
  end

  local title = "FLYING TRENDS"

  if widget.filterYear ~= nil then
    title = title .. " " .. widget.filterYear
  end

  lcd.drawText(z.x + z.w/2, z.y + 8, title, CENTER + MIDSIZE + WHITE)

  lcd.drawText(z.x + z.w/2, z.y + 45, "MONTHLY MODEL FLIGHTS", CENTER + SMLSIZE + LIGHTBROWN)

  --------------------------------------------------
  -- GRAPH AREA
  --------------------------------------------------

  local graphTop = z.y + 70
  local graphBottom = z.y + z.h - 70
  local graphHeight = graphBottom - graphTop

  local graphLeft = z.x + 30
  local graphRight = z.x + z.w - 20
  local graphWidth = graphRight - graphLeft

  --------------------------------------------------
  -- AXES
  --------------------------------------------------

  -- Y-axis (left)
  lcd.drawLine(graphLeft, graphTop, graphLeft, graphBottom, SOLID, WHITE)

  -- X-axis (bottom)
  lcd.drawLine(graphLeft, graphBottom, graphRight, graphBottom, SOLID, WHITE)

  --------------------------------------------------
  -- DETERMINE MAX MONTH
  --------------------------------------------------

  local now = getDateTime()
  local currentYear = now.year
  local currentMonth = now.mon

  local maxMonth = 12

  if widget.filterYear ~= nil then
    if widget.filterYear == currentYear then
      maxMonth = currentMonth
    else
      maxMonth = 12
    end
  else
    maxMonth = 12
  end

  --------------------------------------------------
  -- FIND MAX VALUE (for scaling)
  --------------------------------------------------

  local maxVal = 0

  for _, model in ipairs(widget.models) do
    local data = widget.monthlyModel[model.name]

    if data then
      for m=1,maxMonth do
        local v = data[m] or 0
        if v > maxVal then maxVal = v end
      end
    end
  end

  if maxVal == 0 then maxVal = 1 end
 
  local displayMax = niceMax(maxVal)

  --------------------------------------------------
  -- X STEP
  --------------------------------------------------

  local stepX = graphWidth
  if maxMonth > 1 then
    stepX = graphWidth / (maxMonth - 1)
  end

  --------------------------------------------------
  -- Y SCALE VALUES
  --------------------------------------------------

  local steps = 3
  local stepValue = displayMax / steps

  --------------------------------------------------
  -- Y AXIS LABELS
  --------------------------------------------------

  for i=0,steps do

    local value = math.floor(stepValue * i + 0.5)

    local y = graphBottom - (value / displayMax) * graphHeight

    -- small tick mark
    lcd.drawLine(graphLeft - 4, y, graphLeft, y, SOLID, WHITE)

    -- label
    lcd.drawText(graphLeft - 6, y, tostring(value), SMLSIZE + RIGHT + WHITE)

  end
  
  --------------------------------------------------
  -- DRAW LINES
  --------------------------------------------------

  for _, model in ipairs(widget.models) do

    local data = widget.monthlyModel[model.name]

    if data then

      local prevX, prevY = nil, nil

      for m=1,maxMonth do

        local v = data[m] or 0

        local x = graphLeft + (m-1) * stepX
        local y = graphBottom - (v / displayMax) * graphHeight

        -- point
        lcd.drawFilledRectangle(x-1, y-1, 3, 3, model.color)

        -- line
        if prevX then
          lcd.drawLine(prevX, prevY, x, y, SOLID, model.color)
        end

        prevX = x
        prevY = y
      end
    end
  end

  --------------------------------------------------
  -- MONTH LABELS
  --------------------------------------------------

  local months = {"J","F","M","A","M","J","J","A","S","O","N","D"}

  for m=1,maxMonth do
    local x = graphLeft + (m-1) * stepX
    lcd.drawText(x, graphBottom + 5, months[m], SMLSIZE + CENTER + YELLOW)
  end

  --------------------------------------------------
  -- MODEL LEGEND (BOTTOM)
  --------------------------------------------------

  local count = #widget.models
  local split = math.min(4, count)

  -- Row 1
  local rowY1 = z.y + z.h - 30
  local spacing1 = z.w / (split + 1)

  for i=1,split do
    local model = widget.models[i]
    local x = spacing1 * i
    lcd.drawText(x, rowY1, model.name, SMLSIZE + CENTER + model.color)
  end

  -- Row 2
  local remaining = count - split

  if remaining > 0 then
    local rowY2 = z.y + z.h - 15
    local spacing2 = z.w / (remaining + 1)

    for i=1,remaining do
      local model = widget.models[split + i]
      local x = spacing2 * i
      lcd.drawText(x, rowY2, model.name, SMLSIZE + CENTER + model.color)
    end
  end

end
---------------------------------------------------------------------------
-- DASHBOARD 4 -- MONTHLY MODEL COMPARISON DATA
---------------------------------------------------------------------------
local function drawDashboard4(widget)

  local z = widget.zone

  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)

    return
  end

  local title = "FLYING TRENDS"

  if widget.filterYear ~= nil then
    title = title .. " " .. widget.filterYear
  end

  lcd.drawText(z.x + z.w/2, z.y + 8, title, CENTER + MIDSIZE + WHITE)
  lcd.drawText(z.x + z.w/2, z.y + 45, "MONTHLY MODEL FLIGHTS", CENTER + SMLSIZE + LIGHTBROWN)

  --------------------------------------------------
  -- TABLE LAYOUT
  --------------------------------------------------

  local startX = z.x + 65   
  local startY = z.y + 70

  local rowHeight = 18
  local colWidth = (z.w - startX - 10) / 12

  --------------------------------------------------
  -- MONTH HEADER
  --------------------------------------------------

  local months = {"J","F","M","A","M","J","J","A","S","O","N","D"}

  for m=1,12 do
    local x = startX + (m-1)*colWidth
    lcd.drawText(x + colWidth/2, startY, months[m], SMLSIZE + CENTER + YELLOW)
  end

  --------------------------------------------------
  -- MODEL ROWS
  --------------------------------------------------

  for i, model in ipairs(widget.models) do

    local y = startY + i * rowHeight

    -- model name
    lcd.drawText(z.x + 5, y, model.name, SMLSIZE + model.color)

    local data = widget.monthlyModel[model.name]

    if data then
      for m=1,12 do

        local v = data[m] or 0
        local x = startX + (m-1)*colWidth

        lcd.drawText(x + colWidth/2, y, tostring(v), SMLSIZE + CENTER + WHITE)

      end
    end

  end

end

---------------------------------------------------------------------------
-- DASHBOARD 5 -- CURRENT MODEL CALENDAR
---------------------------------------------------------------------------
local function drawDashboard5(widget)

  local z = widget.zone

  local ch1 = getValue("ch1") or 0

  if not widget.calendarYear then
    local now = getDateTime()
    widget.calendarYear = now.year
    widget.calendarMonth = now.mon
  end

  if ch1 > 300 and widget.calendarLastCh1 <= 300 then
    widget.calendarMonth = widget.calendarMonth + 1
    if widget.calendarMonth > 12 then
      widget.calendarMonth = 1
      widget.calendarYear = widget.calendarYear + 1
    end
  elseif ch1 < -300 and widget.calendarLastCh1 >= -300 then
    widget.calendarMonth = widget.calendarMonth - 1
    if widget.calendarMonth < 1 then
      widget.calendarMonth = 12
      widget.calendarYear = widget.calendarYear - 1
    end
  end

  widget.calendarLastCh1 = ch1

  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)
    return
  end

  lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)

  lcd.drawText(z.x + z.w/2,z.y + 8,"FLYING CALENDAR",CENTER + MIDSIZE + WHITE)

  if not widget.calendarYear then
    local now = getDateTime()
    widget.calendarYear = now.year
    widget.calendarMonth = now.mon
  end

  local monthNames = {"January","February","March","April","May","June","July","August","September","October","November","December"}

  lcd.drawText(z.x + z.w/2,z.y + 55,monthNames[widget.calendarMonth] .. " " .. widget.calendarYear,CENTER + MIDSIZE + YELLOW)

  local mdays = {31,28,31,30,31,30,31,31,30,31,30,31}

  if widget.calendarMonth == 2 then
    if (widget.calendarYear % 4 == 0 and widget.calendarYear % 100 ~= 0)
       or widget.calendarYear % 400 == 0 then
      mdays[2] = 29
    end
  end

  local daysInMonth = mdays[widget.calendarMonth]

  local m = widget.calendarMonth
  local y = widget.calendarYear

  if m < 3 then
    m = m + 12
    y = y - 1
  end

  local K = y % 100
  local J = math.floor(y / 100)

  local h = (1 + math.floor((13*(m+1))/5) + K + math.floor(K/4) + math.floor(J/4) + 5*J) % 7

  local firstWday = (h + 6) % 7

  local gridX = z.x + 8
  local gridY = z.y + 85
  local cellW = math.floor((z.w - 16) / 7)
  local cellH = 24

  local dayNames = {"S","M","T","W","T","F","S"}

  for i=1,7 do
    lcd.drawText(gridX + (i-1)*cellW + cellW/2,gridY,dayNames[i],SMLSIZE + CENTER + YELLOW)
  end

  local currentName = model.getInfo().name
  local currentCalendar = nil

  for i=1,#widget.models do
    if widget.models[i].name == currentName then
      currentCalendar = widget.models[i].calendar
      break
    end
  end

  for day=1,daysInMonth do
    local pos = firstWday + day - 1
    local row = math.floor(pos / 7)
    local col = pos % 7

    local x = gridX + col*cellW + cellW/2
    local y = gridY + 20 + row*cellH

    local key = string.format("%04d-%02d-%02d",widget.calendarYear,widget.calendarMonth,day)
    local flights = currentCalendar and currentCalendar[key] or 0
    local dayColor = flights > 0 and GREEN or WHITE

    --for i=1,#widget.models do
      --if widget.models[i].calendar and widget.models[i].calendar[key] then
        --dayColor = GREEN
        --break
      --end
    --end
    lcd.drawText(x,y,tostring(day),SMLSIZE + CENTER + dayColor)
    if flights > 0 then
      lcd.drawText(x + 10,y,"(" .. tostring(flights) .. ")",SMLSIZE + YELLOW)
    end
  end

  local currentName = model.getInfo().name
  local first = nil

  for i=1,#widget.models do
    if widget.models[i].name == currentName then
      first = widget.models[i].firstFlightDate
      break
    end
  end

  if first then
    lcd.drawText(z.x + 8,z.y + 50,"First Flight: " .. first, SMLSIZE + WHITE)
  else
    lcd.drawText(z.x + 8,z.y + 50,"First Flight: --/--/----", SMLSIZE + WHITE)
  end

  local currentModelName = model.getInfo().name
  lcd.drawText(z.x + z.w/2, z.y + 30, currentModelName, SMLSIZE + CENTER + WHITE)

  local monthFlightCount = 0
  local monthFlightSeconds = 0

  for day=1,daysInMonth do
    local key = string.format("%04d-%02d-%02d",widget.calendarYear,widget.calendarMonth,day)
    monthFlightCount = monthFlightCount + (currentCalendar and currentCalendar[key] or 0)
  end

  for i=1,#widget.models do
    if widget.models[i].name == currentName then
      if widget.models[i].monthlySeconds then
        monthFlightSeconds = widget.models[i].monthlySeconds[widget.calendarMonth] or 0
      end
      break
    end
  end

  local monthFlightHours = monthFlightSeconds / 3600

  lcd.drawText(z.x + 10,z.y + z.h - 20,"Flight Count: " .. tostring(monthFlightCount),SMLSIZE + WHITE)
  lcd.drawText(z.x + z.w - 10,z.y + z.h - 20,"Flight Hours: " .. string.format("%.1f",monthFlightHours),RIGHT + SMLSIZE + WHITE)


end

---------------------------------------------------------------------------
-- DASHBOARD 6 -- ALL MODELS CALENDAR
---------------------------------------------------------------------------
local function drawDashboard6(widget)

  local z = widget.zone
  local ch1 = getValue("ch1") or 0

  if not widget.calendarYear then
    local now = getDateTime()
    widget.calendarYear = now.year
    widget.calendarMonth = now.mon
  end

  if ch1 > 300 and widget.calendarLastCh1 <= 300 then
    widget.calendarMonth = widget.calendarMonth + 1

    if widget.calendarMonth > 12 then
      widget.calendarMonth = 1
      widget.calendarYear = widget.calendarYear + 1
    end

  elseif ch1 < -300 and widget.calendarLastCh1 >= -300 then
    widget.calendarMonth = widget.calendarMonth - 1

    if widget.calendarMonth < 1 then
      widget.calendarMonth = 12
      widget.calendarYear = widget.calendarYear - 1
    end
  end

  widget.calendarLastCh1 = ch1


  if not widget.done then
    lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 - 10,"DATA LOADING",CENTER + DBLSIZE + WHITE)
    lcd.drawText(z.x + z.w/2,z.y + z.h/2 + 22,"Please Wait...",CENTER + SMLSIZE + YELLOW)
    return
  end

  lcd.drawFilledRectangle(z.x,z.y,z.w,z.h,BLACK)
  lcd.drawText(z.x + z.w/2,z.y + 8,"ALL MODELS CALENDAR",CENTER + MIDSIZE + WHITE)

  local monthNames = {"January","February","March","April","May","June","July","August","September","October","November","December"}
  lcd.drawText(z.x + z.w/2,z.y + 55,monthNames[widget.calendarMonth] .. " " .. widget.calendarYear,CENTER + MIDSIZE + YELLOW)

  local mdays = {31,28,31,30,31,30,31,31,30,31,30,31}

  if widget.calendarMonth == 2 then
    if (widget.calendarYear % 4 == 0 and widget.calendarYear % 100 ~= 0) or widget.calendarYear % 400 == 0 then
      mdays[2] = 29
    end
  end

  local daysInMonth = mdays[widget.calendarMonth]

  local m = widget.calendarMonth
  local y = widget.calendarYear

  if m < 3 then
    m = m + 12
    y = y - 1
  end

  local K = y % 100
  local J = math.floor(y / 100)

  local h = (1 + math.floor((13*(m+1))/5) + K + math.floor(K/4) + math.floor(J/4) + 5*J) % 7

  local firstWday = (h + 6) % 7

  local gridX = z.x + 8
  local gridY = z.y + 85
  local cellW = math.floor((z.w - 16) / 7)
  local cellH = 24

  local dayNames = {"S","M","T","W","T","F","S"}

  for i=1,7 do
    lcd.drawText(gridX + (i-1)*cellW + cellW/2,gridY,dayNames[i],SMLSIZE + CENTER + YELLOW)
  end

  local totalMonthFlights = 0

  for day=1,daysInMonth do

    local pos = firstWday + day - 1
    local row = math.floor(pos / 7)
    local col = pos % 7

    local x = gridX + col*cellW + cellW/2
    local y = gridY + 20 + row*cellH

    local key = string.format("%04d-%02d-%02d",widget.calendarYear,widget.calendarMonth,day)

    local flights = 0

    for i=1,#widget.models do
      local cal = widget.models[i].calendar

      if cal and cal[key] then
        flights = flights + cal[key]
      end
    end

    local dayColor = WHITE

    if flights > 0 then
      dayColor = GREEN
    end

    lcd.drawText(x,y,tostring(day),SMLSIZE + CENTER + dayColor)

    if flights > 0 then
      lcd.drawText(x + 10,y,"(" .. tostring(flights) .. ")",SMLSIZE + YELLOW)
    end

    totalMonthFlights = totalMonthFlights + flights

  end


  -- TOTAL FLIGHT HOURS
  local totalMonthSeconds = 0

  for i=1,#widget.models do
    local model = widget.models[i]

    if model.monthlySeconds then
      totalMonthSeconds = totalMonthSeconds + (model.monthlySeconds[widget.calendarMonth] or 0)
    end
  end

  local totalMonthHours = totalMonthSeconds / 3600

  lcd.drawText(z.x + 10,z.y + z.h - 20,"Flight Count: " .. tostring(totalMonthFlights),SMLSIZE + WHITE)
  lcd.drawText(z.x + z.w - 10,z.y + z.h - 20,"Flight Hours: " .. string.format("%.1f",totalMonthHours),RIGHT + SMLSIZE + WHITE)

end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------
local function refresh(widget)

  process(widget)

  local z = widget.zone

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)

  local slider = getValue("ls") or 0
  local sb = getValue("sb") or 0
  local dashboard

  if sb < -300 then
    if slider < -30 then
      dashboard = 1
    elseif slider < 30 then
      dashboard = 2
    else
      dashboard = 3
    end
  elseif sb <= 300 then
    dashboard = 5
  else
    dashboard = 6
  end

  widget.dashboard = dashboard

  if dashboard == 1 then
    drawDashboard1(widget)
  elseif dashboard == 2 then
    drawDashboard2(widget)
  elseif dashboard == 3 then
    local sh = getValue("sh") or 0

    if sh > 0 then
      drawDashboard4(widget)
    else
      drawDashboard3(widget)
    end
  elseif dashboard == 5 then
    drawDashboard5(widget)
  elseif dashboard == 6 then
    drawDashboard6(widget)
  end

end

---------------------------------------------------------------------------
-- RETURN
---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  update = update,
  refresh = refresh,
  options = options
}
